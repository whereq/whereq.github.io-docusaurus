The save-state reference-count regression test.

The program opens a file, duplicates the handle, waits while a state is
saved and restored, then closes the first handle and reads through the
second one. It prints PASS when the duplicate survived the restore, and
writes the verdict to RESULT.TXT.

See examples/dup-test/README.md in the source tree for the whole story.
