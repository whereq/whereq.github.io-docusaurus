The save-state reference-count regression test.

The program opens a file, duplicates the handle, waits while a state is
saved and restored, then closes the first handle and reads through the
second one. It prints PASS when the duplicate survived the restore.

RESULT.TXT holds the stage the program reached and the verdict, so the
result can be read from the host even when the screen does not update:
"C " while it waits, "P PASS" when it is done, "F FAIL" when it is not.

See examples/dup-test/README.md in the source tree for the whole story.
