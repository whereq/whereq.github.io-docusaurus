/* ===================================================================
   DUP.COM - the save-state reference-count regression test.

   What it checks:

     1. A handle duplicated with INT 21h/45h (DUP) shares ONE entry of
        DOSBox's file table - the count of that entry is 2. The snapshot
        has to save that count and put it back, because
        DOS_CloseFile() deletes the entry when the count reaches zero.

        The test opens a file, duplicates the handle, waits while a state
        is saved and restored, closes the FIRST handle and then reads
        through the SECOND one. If the restore dropped the count to 1,
        the first close would delete the shared entry and the read would
        fail with "invalid handle" (DOS error 6). The test prints PASS
        when the read returns the file's content.

     2. The host file descriptor of the shared handle must not leak on
        every restore. The file stays open across the restore, so the
        descriptor count on DUPTEST.TXT is measured from the host side
        (the number of /proc/<pid>/fd entries pointing at it) before and
        after the restore cycle.

   How it is driven:

     * The bundle's PLAY.BAT starts this program.
     * The program opens the file, duplicates the handle and prints
       "READY", then waits for a key.
     * The operator saves a state and restores it (the launcher's States
       dialog) while the program waits.
     * Any key resumes the program, which closes the first handle and
       reads through the duplicate.

   Build:

     as --32 -o dup.o dup.asm
     ld -m elf_i386 --oformat binary -Ttext 0x100 -e _start -o DUP.COM dup.o
   =================================================================== */

	.code16
	.text
	.globl _start

_start:
	jmp	start

	.bss
handle:	.word	0
dup:	.word	0
buf:	.space	64

	.text
start:
	/* Remove an old file, so the create below starts from nothing. */
	movb	$0x41, %ah
	movw	$fname, %dx
	int	$0x21

	/* Create (or open) the file for reading and writing. */
	movb	$0x3c, %ah
	movw	$0, %cx
	movw	$fname, %dx
	int	$0x21
	jc	open_fail
	movw	%ax, handle

	/* Write the content the read is compared against. */
	movb	$0x40, %ah
	movw	handle, %bx
	movw	$text_len, %cx
	movw	$text, %dx
	int	$0x21
	jc	write_fail

	/* Seek back to the start: the shared position has to be 0. */
	movb	$0x42, %ah
	movb	$0, %al
	movw	handle, %bx
	movw	$0, %cx
	movw	$0, %dx
	int	$0x21
	jc	seek_fail

	/* DUP the handle: the duplicate shares the entry, and the count
	 * of that entry becomes 2. */
	movb	$0x45, %ah
	movb	$0, %al
	movw	handle, %bx
	int	$0x21
	jc	dup_fail
	movw	%ax, dup

	/* Tell the operator to do the save/restore now. */
	movw	$msg_ready, %si
	call	print

	/* Wait for a key: the save and the restore happen while we are
	 * here. */
	xorb	%ah, %ah
	int	$0x16

	/* Close the FIRST handle. With the count restored to 2 the entry
	 * survives - it is still the duplicate's. */
	movb	$0x3e, %ah
	movw	handle, %bx
	int	$0x21

	/* Read through the duplicate. */
	movb	$0x3f, %ah
	movw	dup, %bx
	movw	$text_len, %cx
	movw	$buf, %dx
	int	$0x21
	jc	read_fail
	cmpw	$text_len, %ax
	jne	read_fail

	/* The content has to be the file's content. */
	movw	$buf, %si
	movw	$text, %di
	movw	$text_len, %cx
	repe	cmpsb
	jne	read_fail

	movw	$msg_pass, %si
	call	print
	movw	$pass_text, %dx
	movw	$4, %cx
	call	report
	jmp	done

open_fail:
	movw	$msg_openfail, %si
	call	print
	jmp	err

write_fail:
	movw	$msg_writefail, %si
	call	print
	jmp	err

seek_fail:
	movw	$msg_seekfail, %si
	call	print
	jmp	err

dup_fail:
	movw	$msg_dupfail, %si
	call	print
	jmp	err

read_fail:
	movw	$msg_readfail, %si
	call	print
	jmp	err

err:
	/* The verdict goes to the file as well, so it survives a screen that
	 * is not updating. */
	movw	$fail_text, %dx
	movw	$4, %cx
	call	report
	/* The DOS error code, in AX, after the message. */
	movw	$msg_code, %si
	call	print
	movw	%ax, %dx
	addw	$0x30, %dx
	movb	$0x02, %ah
	int	$0x21
	movw	$msg_crlf, %si
	call	print

done:
	movb	$0x4c, %ah
	movb	$0, %al
	int	$0x21

/* Writes the verdict to RESULT.TXT, so the result can be read from the host
 * even when the screen is not updating. DX = the text, CX = its length. */
report:
	pushw	%ax
	pushw	%bx
	pushw	%cx
	pushw	%dx
	movb	$0x3c, %ah
	movw	$0, %cx
	movw	$result_name, %dx
	int	$0x21
	jc	report_fail
	movw	%ax, %bx
	popw	%dx
	popw	%cx
	movb	$0x40, %ah
	int	$0x21
	popw	%bx
	popw	%ax
	ret
report_fail:
	popw	%dx
	popw	%cx
	popw	%bx
	popw	%ax
	ret

/* Prints the '$'-terminated string at DS:SI. */
print:
	pushw	%ax
	pushw	%dx
	movb	$0x09, %ah
	int	$0x21
	popw	%dx
	popw	%ax
	ret

	.data
fname:	.asciz	"DUPTEST.TXT"
result_name:	.asciz	"RESULT.TXT"
pass_text:	.ascii	"PASS"
fail_text:	.ascii	"FAIL"
text:	.ascii	"ABCDEFGH"
	.set	text_len, 8

msg_ready:	.ascii	"READY: save and restore a state now, then press a key"
	.ascii	"\r\n$"
msg_pass:	.ascii	"PASS: the duplicate survived the restore"
	.ascii	"\r\n$"
msg_openfail:	.ascii	"FAIL: could not create the file, error "
	.ascii	"$"
msg_writefail:	.ascii	"FAIL: could not write the file, error "
	.ascii	"$"
msg_seekfail:	.ascii	"FAIL: could not seek, error "
	.ascii	"$"
msg_dupfail:	.ascii	"FAIL: could not duplicate the handle, error "
	.ascii	"$"
msg_readfail:	.ascii	"FAIL: the read through the duplicate failed, error "
	.ascii	"$"
msg_code:	.ascii	"$"
msg_crlf:	.ascii	"\r\n$"
