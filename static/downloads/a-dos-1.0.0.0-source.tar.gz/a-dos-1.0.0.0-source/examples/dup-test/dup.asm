/* ===================================================================
   DUP.COM - the save-state reference-count regression test.

   What it checks:

     1. A handle duplicated with INT 21h/45h (DUP) shares ONE entry of
        DOSBox's file table - the count of that entry is 2. The snapshot
        has to save that count and put it back, because
        DOS_CloseFile() deletes the entry when the count reaches zero.

        The test opens a file, duplicates the handle, waits while a state
        is saved and restored, closes the FIRST handle and then reads
        through the SECOND one. If the restore dropped the count to 1,
        the first close would delete the shared entry and the read would
        fail with "invalid handle" (DOS error 6). The test prints PASS
        when the read returns the file's content.

     2. The host file descriptor of the shared handle must not leak on
        every restore. The file stays open across the restore, so the
        descriptor count on DUPTEST.TXT is measured from the host side
        (the number of /proc/<pid>/fd entries pointing at it) before and
        after the restore cycle.

   How it is driven:

     * The bundle's PLAY.BAT starts this program.
     * The program opens the file, duplicates the handle and prints
       "READY", then waits for a key.
     * The operator saves a state and restores it (the launcher's States
       dialog) while the program waits.
     * Any key resumes the program, which closes the first handle and
       reads through the duplicate.

   The verdict does not depend on the screen: RESULT.TXT is rewritten
   after every step with the stage the program reached and the verdict
   so far, so the host can read the file even when the picture does not
   update.

     A  the file was opened
     B  the handle was duplicated
     C  the program waits for a key (save/restore happens now)
     D  the first handle was closed
     E  the read through the duplicate returned the expected bytes
     P  the verdict is PASS
     F  the verdict is FAIL

   The file holds the stage letter, a space and the verdict: "C " while
   the program waits, "P PASS" when it is done. A file that still holds
   a stage letter without a verdict means the program stopped in the
   middle (a crash, or a screen that could not be drawn).

   Build:
     as --32 -o dup.o dup.asm
     ld -m elf_i386 --oformat binary -Ttext 0x100 -e _start -o DUP.COM dup.o
   =================================================================== */

	.code16
	.text
	.globl _start

_start:
	jmp	start

	.text
start:
	/* Remove an old file, so the create below starts from nothing. */
	movb	$0x41, %ah
	movw	$fname, %dx
	int	$0x21

	/* Create (or open) the file for reading and writing. */
	movb	$0x3c, %ah
	movw	$0, %cx
	movw	$fname, %dx
	int	$0x21
	jc	open_fail
	movw	%ax, handle
	movb	$'A', %al
	call	setmark

	/* Write the content the read is compared against. */
	movb	$0x40, %ah
	movw	handle, %bx
	movw	$text_len, %cx
	movw	$text, %dx
	int	$0x21
	jc	write_fail

	/* Seek back to the start: the shared position has to be 0. */
	movb	$0x42, %ah
	movb	$0, %al
	movw	handle, %bx
	movw	$0, %cx
	movw	$0, %dx
	int	$0x21
	jc	seek_fail

	/* DUP the handle: the duplicate shares the entry, and the count
	 * of that entry becomes 2. */
	movb	$0x45, %ah
	movb	$0, %al
	movw	handle, %bx
	int	$0x21
	jc	dup_fail
	movw	%ax, dup
	movb	$'B', %al
	call	setmark

	/* Tell the operator to do the save/restore now. */
	movw	$msg_ready, %si
	call	print
	movb	$'C', %al
	call	setmark

	/* Wait for a key: the save and the restore happen while we are
	 * here. */
	xorb	%ah, %ah
	int	$0x16
	movb	$'D', %al
	call	setmark

	/* Close the FIRST handle. With the count restored to 2 the entry
	 * survives - it is still the duplicate's. */
	movb	$0x3e, %ah
	movw	handle, %bx
	int	$0x21

	/* Read through the duplicate. */
	movb	$0x3f, %ah
	movw	dup, %bx
	movw	$text_len, %cx
	movw	$buf, %dx
	int	$0x21
	jc	read_fail
	cmpw	$text_len, %ax
	jne	read_fail
	movb	$'E', %al
	call	setmark

	/* The content has to be the file's content. */
	movw	$buf, %si
	movw	$text, %di
	movw	$text_len, %cx
	repe	cmpsb
	jne	read_fail

	movw	$msg_pass, %si
	call	print
	movw	$pass_text, %si
	movw	$4, %cx
	call	setverdict
	movb	$'P', %al
	call	setmark
	jmp	done

open_fail:
	movw	$msg_openfail, %si
	call	print
	jmp	err

write_fail:
	movw	$msg_writefail, %si
	call	print
	jmp	err

seek_fail:
	movw	$msg_seekfail, %si
	call	print
	jmp	err

dup_fail:
	movw	$msg_dupfail, %si
	call	print
	jmp	err

read_fail:
	movw	$msg_readfail, %si
	call	print

err:
	/* The verdict goes to the file as well, so it survives a screen that
	 * is not updating. */
	movw	$fail_text, %si
	movw	$4, %cx
	call	setverdict
	movb	$'F', %al
	call	setmark
	/* The DOS error code, in AX, after the message. */
	movw	$msg_code, %si
	call	print
	movw	%ax, %dx
	addw	$0x30, %dx
	movb	$0x02, %ah
	int	$0x21
	movw	$msg_crlf, %si
	call	print

done:
	movb	$0x4c, %ah
	movb	$0, %al
	int	$0x21

/* Records the stage letter in AL and rewrites RESULT.TXT. */
setmark:
	pushw	%ax
	movb	%al, stage
	call	write_result
	popw	%ax
	ret

/* Copies the CX bytes at DS:SI into the verdict buffer. */
setverdict:
	pushw	%cx
	pushw	%si
	pushw	%di
	movw	%cx, verdict_len
	movw	$verdict_buf, %di
	rep	movsb
	popw	%di
	popw	%si
	popw	%cx
	ret

/* Rewrites RESULT.TXT with the stage letter and the verdict. The file is
 * created and closed again every time, so it never stays open. */
write_result:
	pushw	%ax
	pushw	%bx
	pushw	%cx
	pushw	%dx
	movb	$0x3c, %ah		/* create (truncates) */
	movw	$0, %cx
	movw	$result_name, %dx
	int	$0x21
	jc	write_result_done
	movw	%ax, %bx
	movb	$0x40, %ah		/* write the stage letter */
	movb	$0, %al
	movw	$1, %cx
	movw	$stage, %dx
	int	$0x21
	movb	$0x40, %ah		/* write a space */
	movb	$0, %al
	movw	$1, %cx
	movw	$space, %dx
	int	$0x21
	movb	$0x40, %ah		/* write the verdict */
	movb	$0, %al
	movw	verdict_len, %cx
	movw	$verdict_buf, %dx
	int	$0x21
	movb	$0x3e, %ah		/* close */
	movb	$0, %al
	int	$0x21
write_result_done:
	popw	%dx
	popw	%cx
	popw	%bx
	popw	%ax
	ret

/* Prints the '$'-terminated string at DS:SI. */
print:
	pushw	%ax
	pushw	%dx
	pushw	%si
	movw	%si, %dx
	movb	$0x09, %ah
	int	$0x21
	popw	%si
	popw	%dx
	popw	%ax
	ret

	.data
fname:	.asciz	"DUPTEST.TXT"
result_name:	.asciz	"RESULT.TXT"
pass_text:	.ascii	"PASS"
fail_text:	.ascii	"FAIL"
text:	.ascii	"ABCDEFGH"
	.set	text_len, 8
space:	.byte	' '
stage:	.byte	'A'
verdict_len:	.word	0
verdict_buf:	.space	8

/* The working variables live in .data, not in .bss: a .COM file is
 * loaded as it is written, so anything that has to start at a known
 * value has to be in the file itself. */
	.data
handle:	.word	0
dup:	.word	0
buf:	.space	64

msg_ready:	.ascii	"READY: save and restore a state now, then press a key"
	.ascii	"\r\n$"
msg_pass:	.ascii	"PASS: the duplicate survived the restore"
	.ascii	"\r\n$"
msg_openfail:	.ascii	"FAIL: could not create the file, error "
	.ascii	"$"
msg_writefail:	.ascii	"FAIL: could not write the file, error "
	.ascii	"$"
msg_seekfail:	.ascii	"FAIL: could not seek, error "
	.ascii	"$"
msg_dupfail:	.ascii	"FAIL: could not duplicate the handle, error "
	.ascii	"$"
msg_readfail:	.ascii	"FAIL: the read through the duplicate failed, error "
	.ascii	"$"
msg_code:	.ascii	"$"
msg_crlf:	.ascii	"\r\n$"
