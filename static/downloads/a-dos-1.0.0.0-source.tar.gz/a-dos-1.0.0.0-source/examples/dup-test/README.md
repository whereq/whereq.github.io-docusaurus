# The save-state reference-count test

A small DOS program that checks the one thing the save state has to get
right about the DOS file table: **a handle duplicated with INT 21h/45h (DUP)
shares one entry of that table, and the snapshot has to save the share count
and put it back.**

## What it checks

The program

1. creates `DUPTEST.TXT`, writes `ABCDEFGH` into it and seeks back to the
   start,
2. duplicates the handle (INT 21h/45h) — from here on, two DOS handles point
   at **one** table entry, whose reference count is 2,
3. prints `READY` and waits for a key,
4. closes the **first** handle and reads through the **second** one,
5. prints `PASS` when the read returns the file's content, and writes the
   verdict to `RESULT.TXT` as well.

If the restore dropped the reference count to 1 — which a "tidy up the
restore" change is quick to do — the first close deletes the shared entry and
the duplicate is left pointing at nothing: the read fails with *invalid
handle* (DOS error 6) and the test prints `FAIL`.

The file descriptor of the shared handle is the second thing the test is for:
it stays open across the restore, and the host descriptor behind it must not
leak. The count is read from the host side:

```sh
adb shell run-as com.whereq.ados ls -l /proc/$(adb shell pidof com.whereq.ados)/fd \
    | grep -c DUPTEST
```

One descriptor before the restore and one after it. Without the forced close
in the discard loop of `DOS_LoadState()`, every restore of a state in which
a handle was shared left one more descriptor open.

## Running it

```sh
./build.sh                       # needs the repository toolchain
adb push dist/dup-test-bundle.zip /sdcard/Download/
```

In the app: tap **File** on the on-screen keyboard, tap **Install a bundle
(.zip)** and pick the archive. Then tap **Play** on `dup-test-bundle` — the
emulator reboots into the test, which prints `READY`.

While it waits:

1. tap **File**, then **States** on the bundle's row,
2. tap **Save** on slot 1,
3. tap **States** again and tap **Load** on slot 1 — the machine is replaced
   and the program is back at its `READY` prompt,
4. press any key.

The program then prints `PASS` and writes `RESULT.TXT` into the game's
folder:

```sh
adb shell run-as com.whereq.ados cat /data/data/com.whereq.ados/files/GAMES/G1/RESULT.TXT
```

## What the log says

The restore logs the shared entry with its restored count:

```
savestate: dos handle 4: GAMES\G1\DUPTEST.TXT (drive 2, pos 0, refs 2)
savestate: dos state restored: drive 2, code page 437, 5 handle(s)
```

`refs 2` is the point: the count came back as it was saved. With the count
forced to 1 it would read `refs 1`, and the duplicate would be dead.
