#!/bin/sh
# ===========================================================================
#  Build the save-state reference-count regression test.
#
#  The test is a DOS .COM program, so it is built with the GNU assembler and
#  linker that come with the repository toolchain:
#
#      as --32 -o dup.o dup.asm
#      ld -m elf_i386 --oformat binary -Ttext 0x100 -e _start -o DUP.COM dup.o
#
#  The result is packed into a bundle zip that A-DOS installs like any other
#  bundle: unzip it in the launcher, press Play, and the program waits for
#  you to save a state and restore it.
#
#  Usage:  ./build.sh
# ===========================================================================

set -e

here=$(cd "$(dirname "$0")" && pwd)
cd "$here"

toolchain="../../toolchain/env.sh"
if [ ! -f "$toolchain" ]; then
        echo "build.sh: the repository toolchain is missing ($toolchain)" >&2
        exit 1
fi

# the toolchain has to be sourced, not run
. "$toolchain"

mkdir -p build dist

echo "assembling dup.asm"
as --32 -o build/dup.o dup.asm

echo "linking DUP.COM"
ld -m elf_i386 --oformat binary -Ttext 0x100 -e _start \
        -o build/DUP.COM build/dup.o

echo "packing the bundle"
rm -f dist/dup-test-bundle.zip
cp build/DUP.COM bundle/DUP.COM
(cd bundle && zip -q -X ../dist/dup-test-bundle.zip DUP.COM PLAY.BAT README.TXT)

echo "wrote dist/dup-test-bundle.zip"
