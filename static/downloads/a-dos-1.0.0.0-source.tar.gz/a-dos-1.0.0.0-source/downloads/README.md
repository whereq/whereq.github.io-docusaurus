# Downloads

The release APK of **A-DOS**, for people who want to try the app
without building it.

**The APK is not in this repository.** CI builds it from the release tag and
publishes it as a release asset, so the file you download is the file that was
built, signed and verified — one artifact, one checksum, one place.

**A-DOS starts at v1.0.0.0.** The releases before the rename — up to
v1.0.0.12 — were published from the predecessor repository and stay there, on
the [releases page](https://github.com/whereq/whereq-dosbox/releases) from
1.0.0.9 on; the ones before that were never released there and live in that
repository's history, at their own tag — for example
`https://raw.githubusercontent.com/whereq/whereq-dosbox/v1.0.0.8/downloads/whereq-dosbox-1.0.0.8.apk`.

The A-DOS releases are published from this repository, as
`a-dos-<version>.apk` next to its `.sha256` sidecar. The **App Bundle**
(`a-dos-<version>.aab`) is published next to it — that is the format Google
Play accepts for a new app, and it is the file to upload to the Play
Console. See [docs/PLAY-STORE.md](../docs/PLAY-STORE.md).

**A-DOS collects no data.** The app has no `INTERNET` permission, no
analytics and no third-party SDK; everything it writes stays on your device.
The privacy policy is in [docs/PRIVACY.md](../docs/PRIVACY.md), which is the
authoritative copy, and it is published at
<https://whereq.github.io/docs/privacy/a-dos/> — the app links to the
published page from the footer of its launcher.

## The current release

| version | file | size |
|---|---|---|
| 1.0.0.12 | [`whereq-dosbox-1.0.0.12.apk`](https://github.com/whereq/whereq-dosbox/releases/download/v1.0.0.12/whereq-dosbox-1.0.0.12.apk) | 16 536 964 bytes (15.8 MB) |

* SHA-256 of the 1.0.0.12 APK:
  `67577d59e078cd2953c24ea24753068aae2a01c2cf27a9788644787e999f2fd9`
* Signing certificate (SHA-256):
  `b16b480d5a1ff6d35baff0b15fa3fc4b0ee815e500861fbff1b062c9bf7d3933`

1.0.0.12 is the last release of the **predecessor** series: it is the release
that introduced the A-DOS name, and it was published from
[`whereq/whereq-dosbox`](https://github.com/whereq/whereq-dosbox) under the
old file name. The first A-DOS release — v1.0.0.0 — is published from this
repository as `a-dos-1.0.0.0.apk`, and it carries the same signing
certificate, so the two can be installed side by side.

## What changed in 1.0.0.0

The first release of the **A-DOS** series — the rename, from end to end.

* **The project is A-DOS.** The app label, the launcher icons, the
  notification, the native product strings (the DOS startup banner, the window
  title, the configuration dialog and the generated headers), the package, the
  repository and the published file names all carry the new name. The mark is
  new too — the metallic triangle with the green `C:\>` prompt inside it.
* **The package is `com.whereq.ados`.** A new application id means a **new
  app on the phone**: Android cannot update `com.whereq.dosbox` into
  `com.whereq.ados`, so the old one stays on the device until it is
  uninstalled. The two apps share nothing — not the private storage, not the
  local save-state slots. The **durable saves folder** is the exception: it is
  a folder *you* picked on the phone, so both apps read and write it, and the
  games and their save states carry over.
* **The published file is `a-dos-<version>.apk`**, next to its `.sha256`
  sidecar. The series starts at **v1.0.0.0**; the releases before it, up to
  v1.0.0.12, stay in the predecessor repository.
* **A restored slot keeps its save time.** Loading a slot out of the durable
  folder rewrites the local file, so the slot used to show *just now* after
  every restore. The durable copy's timestamp is copied back, and the slot
  shows when the game was really saved.

The features themselves are unchanged: the durable saves folder, the save
state that freezes the whole machine, the RMB key and the second-finger right
click, the three on-screen keyboard layouts and the bundle launcher.

## What changed in 1.0.0.12

A **patch** on the `android-migration-complete` milestone: the mouse work that
closed the Android migration phase is what 1.0.0.11 shipped, and this release
repairs the packaging around it, renames the app and moves the saves out of
the app's own storage. The milestone marker
`milestone/android-migration-complete` moves on to this release.

* **The app is now called A-DOS.** The launcher name, the notification and the
  launcher icons all carry the new name and mark — DOS across Android and
  Apple. In this release the repository, the package name and the download
  file names still say `whereq-dosbox`; the A-DOS series moves all three to
  the new name, starting at v1.0.0.0.
* **Your saves survive a reinstall.** The save-state slots lived in the app's
  private storage, and Android deletes that when the app is uninstalled — so
  reinstalling used to mean losing every save. Pick a folder on the phone
  (**Config → Saves folder**, or the offer that appears after the first save)
  and every slot is mirrored there, gzipped, next to the game itself. A
  reinstall, a new phone or a deleted app therefore all come back: the games
  are offered for restore by name, with their save states already there. Two
  archives with the same file name are told apart by name — *game* and *game
  (2)* — so their saves never end up in the same place.
* **The save state keeps the mouse driver's configuration and none of its
  run-time state.** 1.0.0.11 put the *whole* INT 33h driver into the snapshot
  — the event queue, the click counters and the interrupt re-entrancy flags
  included. Restoring that wedged mouse-driven games: the stale queue and
  flags fed garbage into the INT 74 handler and into the game's own callback,
  and a game could hang on load. The snapshot now carries only the
  configuration the guest cannot rebuild itself — the game's event-callback
  registration, the cursor range and position, the cursor shape and hotspot,
  the granularity and the sensitivity — and the volatile state is left clean,
  so a restored game starts from an idle driver. The cursor shape matters too:
  without it the visible cursor reverts to the default block and no longer
  lines up with the real click point.
* **The emulator knows its own version.** The version was a literal `1.0.0.1`
  in the Android config template, so the DOS startup banner and the window
  title said *WhereQ-DOSBox version 1.0.0.1* no matter which release was
  installed, the BIOS machine string said 1.0.0.1, and the mapper file was
  always `mapper-1.0.0.1.map`. The native build now reads the same `VERSION`
  file that the release script writes and the app reads, so the version in the
  banner and the version on this page cannot disagree.
* **A local build ships all three ABIs.** `android/build-android.sh` and
  `android/build-sdl2.sh` defaulted to two of them, so an APK built from a
  plain `./bin/build.sh apk` did not carry the same ABI set as the published
  one. Both now build `arm64-v8a`, `armeabi-v7a` and `x86_64` by default — the
  same set CI builds.

**Save states written by 1.0.0.11 and by the earlier 1.0.0.12 cuts cannot be
loaded by this build**: the state file grew a version when the mouse block
changed, and an older state is refused rather than misread. Save states
written by this build load normally.

One consequence of the volatile half staying out: the button state is not
captured, so a restored game starts with the mouse released and a click that
was held down across the save has to be pressed again.

**This release was re-cut.** The tag still reads `v1.0.0.12`, but the file
behind the download link is a different build than the one first published
under that name, so its checksum is a different one. The checksum at the top of
this page is the current one.

One consequence of the slimmed block: the button state is no longer captured,
so a restored game starts with the mouse released and a click that was held
down across the save has to be pressed again.

## What changed in 1.0.0.11

* **The mouse has a right button.** A DOS mouse has two buttons and a
  touchscreen has one, so there was no way to send a right click — and in most
  DOS games the right button is *cancel* or *back*. The on-screen keyboard now
  has an **RMB** key on the left pad, next to **Tab**, and a **second finger**
  on the picture does the same at that finger's own position.
* **A click is a held button, not a tap.** The first finger holds the **left**
  button for as long as it is down, so a drag still drags, and the right button
  is held the same way. This is what a game that reads the mouse *live* needs:
  the button state at INT 33h AX=3. A click that was over in a millisecond
  could fall between two polls and be missed altogether.
* **The mouse survives a save state.** The INT 33h driver keeps its state
  outside the guest's memory — the game's event-callback registration, the
  cursor range and the button state. It was not in the snapshot, so after a
  restore the cursor still moved but the game's clicks stopped reaching it: a
  dialog's *confirm* button did nothing. The driver is now part of the state.

**Save states written by 1.0.0.10 cannot be loaded by this build.** The state
file grew a version when the mouse driver joined the snapshot, and an older
state is refused rather than misread.

This release carried the **milestone tag** for the end of the Android
migration phase — `milestone/android-migration-complete`, the same marker that
was placed at 1.0.0.10 and has since been moved on to 1.0.0.12.

The rest of the emulator core is unchanged — this release is the app layer and
the mouse driver.

## What changed in 1.0.0.10

* **The sound survives a save state.** The FM chip is now snapshotted
  *exactly* — the envelope, the wave phase and the LFO counter all come back
  with the state. In 1.0.0.9 the chip was not in the snapshot at all: the music
  kept playing while the rest of the machine was rewound, and it was gone
  entirely when a state was restored into a fresh process. Now the sound comes
  back with the machine, in the middle of the note rather than at the
  beginning of it. The PC speaker comes back silent instead of droning on its
  own.
* **A key no longer sticks.** Rotating the phone while a key was held left
  that key pressed in DOSBox for ever. Every key that is down is now released
  when the layout is rebuilt, and a modifier that is shown in two places (the
  pad and the fold-up panel) counts its fingers instead of assuming there is
  only one.
* **The launcher fits on the screen.** The **Files** panel measures the space
  it has and caps the game list to it, so a third game no longer pushes its
  buttons off the bottom edge where nothing could bring them back.
* **The desktop build links again.** The save-state code was missing from the
  autotools build and the two archives had a circular dependency — the
  desktop baseline compiles and links again.
* **A technical reference.** `docs/TECHNICAL-REFERENCE.md` in the repository
  describes the whole implementation with the diagrams: the native build, the
  save-state machine, the exact FM snapshot, the bundle launcher, the
  on-screen keyboard, the throughput benchmark, what is still open and the
  screenshot gallery.

**Save states written by 1.0.0.9 cannot be loaded by this build.** The state
file grew a version when the sound chips became part of the snapshot, and an
older state is refused rather than misread.

This release carried the **milestone tag** for the end of the Android
migration phase; the marker has since moved on to 1.0.0.12, which carries the
same state. What follows is maintenance: bug fixes and documentation.

## What changed in 1.0.0.9

* **The keyboard is a console now.** In landscape the keys sit in the two
  black bars beside the picture, the way a handheld console is built: the
  picture in the middle, one hand on each side, nothing on top of the
  picture. The **left pad** holds the arrow keys as a D-pad (up on top, left
  and right side by side, down below) and the left half of a split QWERTY,
  with **File**, **Esc** and **Tab** along the top. The **right pad** holds
  the action keys — **Alt**, **Ctrl**, **Shift**, **Space**, **Enter** — and
  the right half of the QWERTY, with **#+=**, **Fn** and Backspace along the
  top.
* **Three layers, one key each.** **#+=** swaps both halves for the
  punctuation, **Fn** for F1–F12, Ins/Del, Home/End, PgUp/PgDn, Caps, PrtSc
  and Pause. The switched key lights up while its layer is on. The letter
  layer of the right half already carries `: . / \`, so a DOS path needs no
  layer switch at all.
* **Modifiers work both ways.** *Tap* Ctrl, Alt or Shift and it stays armed
  for the next key — Ctrl, then C. *Hold* it and it behaves like a real key
  for as long as the finger is down, which is what a game expects from its
  fire and strafe keys while the other thumb steers.
* **The layout follows the screen.** A letterbox bar of at least 116 dp gets
  the full pads; a narrower one gets a single key column per side and the
  fold-up QWERTY; portrait gets a slim strip along the bottom. The letter
  keys come to about 33 dp wide on a 20:9 screen and about 24 dp on an 18:9
  one — tight on the narrowest phones, where the D-pad and the action keys
  keep their full size.

The emulator core is the one from 1.0.0.8, unchanged — the whole change is
in the app layer.

## What changed in 1.0.0.8

* **Save states.** Every game gets three slots. **States** in the Files panel
  opens them; **Save** freezes the whole running machine — the CPU, the DOS
  memory, the video memory, the open DOS file handles, the hardware timers —
  and **Load** jumps back to that exact moment. A slot is a file on the phone,
  so it survives quitting the app and rebooting the phone.
* **Resume resumes.** The **Resume** button used to start the last game from
  the beginning. It now restores its newest save state, so the player
  continues where they left off. With no save state the game starts from the
  beginning, as before.
* **The arrows are an inverted T.** In landscape the four arrow keys sit in
  the right-hand column the way they do on a real keyboard — up on top, left
  and right side by side, down below.
* **The game keeps running.** While a game is running, a small ongoing
  notification holds the emulator process, so switching to another app no
  longer loses the game. Tap the notification to come back to the same frame.

Some old DOS programs do not survive a restore — the extender of Ultima VIII
still aborts on it. That is a limitation of the DOS internals the snapshot
does not capture yet, not of the app; `docs/TECHNICAL-REFERENCE.md` has the
details.

## What changed in 1.0.0.7

* **The CPU core can be changed in the app.** The **Config** button in the
  Files panel offers the five cores DOSBox knows: `auto` (the default),
  `normal`, `dynamic`, `simple` and `prefetch`. In 1.0.0.6 the fallback to
  `core=normal` was only documented — the configuration file is regenerated
  on every boot, so it could not be edited on the phone.
* The keyboard of that release is two columns in the letterbox bars
  (the modifiers on the left, **File**, **Ent**, **Space** and the arrows on
  the right). The README shows it.

## What changed in 1.0.0.6

The CPU core is now `core=auto`. A program that stays in real mode runs on the
interpreter, exactly as before; a program that switches into protected mode
hands over to the recompiling (JIT) core, which is compiled into the native
library for all three ABIs. Both paths were verified on the emulator —
STARFALL in real mode, Ultima VIII in protected mode.

If the JIT code cache cannot be allocated, `core=normal` is the fallback —
from 1.0.0.7 on it can be picked in the app, see above.

## Installing it

1. Copy the apk to the phone (cable, cloud drive, whatever is at hand).
2. Open it with the Files app.  Android asks whether to allow installing
   unknown apps from that app — allow it.
3. Install, then open **A-DOS**.

The APK is signed with the release key of this repository, so it can be
updated in place: a later version replaces it without uninstalling first.

One exception: **A-DOS itself is a new application id** (`com.whereq.ados`
instead of `com.whereq.dosbox`), so Android installs it *beside* the old one
rather than over it. Uninstall the old app when you are happy with the new
one. Your save states are safe either way — they live in the durable saves
folder you picked, not in the app's own storage.

The SHA-256 of the current release is at the top of this file; every release
carries its own `.sha256` sidecar next to the APK on the [releases
page](https://github.com/whereq/A-DOS/releases).

## What to try first

The app starts in a DOS prompt.  The **File** button in the on-screen
keyboard opens the launcher, where a bundle can be installed — and
[`examples/game-bundle`](../examples/game-bundle) holds **STARFALL**, a small
arcade game that shows what a bundle looks like when it runs.  Its bundle
zip is [`whereq-demo-bundle.zip`](../examples/game-bundle/dist/whereq-demo-bundle.zip);
install it with *Install a bundle (.zip)*.

To hear the save-state fix for yourself, install
[`examples/opl-test-bundle`](../examples/opl-test-bundle): it programs one
sustained tone on the FM chip and then waits for a key.  Save a state while it
plays, wait a couple of minutes, load the state — the tone continues from the
middle of its attack instead of starting over, and the log lines written by the
save and by the load are identical.

## Building it yourself

The APK is built from this repository with Gradle:

```sh
WHEREQ_RELEASE_KEYSTORE="$PWD/build/release.keystore" \
WHEREQ_RELEASE_STORE_PASS='<the release key password>' \
WHEREQ_RELEASE_ALIAS=whereq \
    ./bin/build.sh apk --release
```

Without the release key the Gradle build falls back to the debug key, and the
resulting APK is *debuggable* — it cannot be installed over a release-signed
one (Android refuses it with `INSTALL_FAILED_UPDATE_INCOMPATIBLE`).

A local build is for your own phone. The APK people download is built by CI
from the release tag, so the published file is the one that was signed,
verified and announced — see [docs/TECHNICAL-REFERENCE.md](../docs/TECHNICAL-REFERENCE.md)
for the details.
