# A-DOS 1.0.0.0 — source release

This is the complete corresponding source code of the **A-DOS 1.0.0.0** build
for Android (`com.whereq.ados`), published as GPLv2 section 3 requires: every
person who receives the binary receives its source as well.

| | |
|---|---|
| Version | 1.0.0.0 (`versionCode` 1000000) |
| Source commit | `5261092` — *"Silence the PC speaker when its amplifier is gated off"* |
| Licence | GNU General Public License, version 2 (see `COPYING`) |
| Attribution | see `NOTICE` |
| Privacy policy | <https://whereq.github.io/docs/privacy/a-dos/> |

## What is in here

The tree is the source of the release commit, with the build history and the
working directory left out:

| Directory | What it is |
|---|---|
| `src/`, `include/`, `scripts/`, `visualc_net/` | the DOSBox r4305 core, with its per-file copyright and licence headers intact |
| `android/` | the Android application (Kotlin) and the NDK/CMake build of the native library |
| `native/` | the desktop Linux baseline build of the same core |
| `bench/`, `toolchain/`, `third_party/` | the CPU-core probe, the rootless dev toolchain, the SDL2 fetch script |
| `bin/` | `build.sh` and `release.sh` — the build and release entry points |
| `docs/` | the technical reference and the publishing guide |
| `examples/` | the example bundles: STARFALL, and the save-state test |

## What this build changes

**No foreground service.** The `specialUse` foreground service and the
`FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE` and `POST_NOTIFICATIONS`
permissions are gone. The app declares one permission, `VIBRATE`. Leaving the
app ends the emulator process; the save states you made are what bring the
game back. See `docs/releases/1.0.0.0.md`.

**The sound is tuned for a phone.** The mixer's defaults (44100 / block size
1024 / prebuffer 25 ms) are tuned for a desktop; under the steady CPU load of
OPL/FM music the mixer's rate-tracking loop hunts and bends a sustained FM note
into an audible warble. This build runs the mixer at 48000, the native rate of
most phones, with a larger block and a deeper prebuffer
(`android/app/src/main/assets/dosbox.conf`).

**The mixer interpolates the channels that do not run at its own rate.** The
OPL and the PC speaker are created at 44100 Hz while the mixer runs at
48000 Hz, and `MIXER_AddChannel()` overwrote the flag that decides how such a
channel is read back — so every resampled channel was *held* instead of
interpolated, which put the images of the carrier back into the audio band
and roughened every sustained FM note. Measured on this build, capturing the
mixer output of a sustained 440 Hz OPL note: the non-harmonic junk under the
note drops from −11.7 dB to −51.3 dB relative to the fundamental. The
carrier was never wrong — 440.003 Hz, +0.0 cents against A4, a pitch wander
of 1.8 cents, no clipped samples.

**The PC speaker falls silent when it is switched off.** Port 61h bit 0 gates
the speaker amplifier, and with the gate closed the output is 0 V. The code
held the *low level of the square wave* instead and walked it back to zero
one step per mixer block, so every beep left a −15 % FS DC step behind that
took about 4.5 seconds to decay — a thump after every sound effect. The beep
itself is unchanged: the same 994 Hz square wave at the same level. With the
step gone, the DC offset under a sustained FM note measures −49.7 dB below
the peak, where it used to be −13 dB.

**The release build refuses to sign itself.** `bin/build.sh apk --release`
fails with an actionable message unless a release keystore is configured —
there is no silent fall back to the debug key. See `BUILDING.md`.

## Building it

The build needs the NDK, the Android SDK and a C/C++ toolchain; `BUILDING.md`
and `bin/build.sh doctor` say what is missing.

```sh
./bin/build.sh bootstrap            # fetch SDL2 and build the toolchain
./bin/build.sh android --abis "arm64-v8a armeabi-v7a x86_64"
./bin/build.sh apk --release        # the signed APK
```

**SDL2 is not in this tree.** `third_party/fetch-sdl2.sh` downloads the exact
release the build uses — SDL2 **2.30.0** — from

```
https://github.com/libsdl-org/SDL/releases/download/release-2.30.0/SDL2-2.30.0.tar.gz
```

SDL2 is distributed under the zlib licence, so its notice has to travel with
the binary (it is in `NOTICE`) but its source does not have to be published.
`./bin/build.sh bootstrap` runs the fetch script for you.

## The other licences

The DOSBox core and the porting work on top of it are GPLv2 — the porting
work is a derivative of the core and cannot be relicensed. The runtime
dependencies of the Android app (the Kotlin standard library and the AndroidX
support libraries) are Apache-2.0 and do not collect or transmit anything.

## Trademarks

"DOSBox" is a trademark of the DOSBox project. This port is not affiliated
with, sponsored or endorsed by the DOSBox team.
