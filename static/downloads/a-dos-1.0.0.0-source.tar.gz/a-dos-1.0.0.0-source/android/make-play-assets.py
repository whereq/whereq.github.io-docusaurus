#!/usr/bin/env python3
"""make-play-assets.py - generate the Google Play Console assets from the A-DOS brand.

The Play Console rejects an asset it cannot read, so the geometry is not
optional:

    icon-512.png          512x512 PNG          the store icon
    feature-1024x500.png  1024x500 PNG/JPEG    the banner, no alpha allowed
    screenshot-0N-*.png   1920x1080 PNG       the phone screenshots

The screenshots are 16:9 because Play only accepts an aspect ratio between
16:9 and 9:16, and a phone capture is usually 20:9 - the long side would be
more than twice the short one and the upload would be refused. A 2400x1080
capture is therefore scaled to 1920x864 and centred on a 1920x1080 canvas in
the brand colour.

Usage:
    ./android/make-play-assets.py [--shots DIR] [--check]

    --shots DIR   where the raw captures live (default: build/play-shots)
    --check       verify the committed assets match a fresh render; write
                  nothing, exit 1 on a mismatch.

Requires Python 3 with Pillow:
    python3 -m pip install --user pillow
"""

import argparse
import glob
import os
import sys

try:
    from PIL import Image
except ImportError:
    sys.exit("Pillow is required: python3 -m pip install --user pillow")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RESOURCES = os.path.join(ROOT, "resources")
OUT = os.path.join(RESOURCES, "play")

# The brand colour: the launcher's adaptive-icon background, sampled from the
# logo by make-icons.py. The Play assets use the same one, so the store and
# the app look like the same product.
BACKGROUND = (0x0D, 0x0D, 0x1F)

# The store icon and the feature graphic.
ICON_SIZE = 512
FEATURE_SIZE = (1024, 500)

# The phone screenshots: 16:9, the only ratio Play accepts for a landscape
# phone shot.
SHOT_SIZE = (1920, 1080)

# The raw captures and what they become. The order is the order the shots
# should appear in the listing. Every shot is a fresh capture of the release
# build, taken on an emulator that nothing else was driving.
SHOTS = [
    ("103-home.png", "screenshot-01-home.png"),
    ("104-launcher.png", "screenshot-02-launcher.png"),
    ("105-licences.png", "screenshot-03-licences.png"),
    ("106-starfall.png", "screenshot-04-starfall.png"),
]


def load(path):
    im = Image.open(path)
    return im.convert("RGBA") if im.mode in ("RGBA", "LA", "P") else im.convert("RGB")


def contain(im, size):
    """Scales the image to fit inside size, keeping its aspect ratio."""
    w, h = size
    scale = min(w / im.width, h / im.height)
    return im.resize((max(1, round(im.width * scale)), max(1, round(im.height * scale))), Image.LANCZOS)


def paste(canvas, im, box):
    """Pastes an image, using its alpha channel as the mask when it has one."""
    if im.mode == "RGBA":
        canvas.paste(im, box, im.getchannel("A"))
    else:
        canvas.paste(im, box)


def on_background(im, size, background=BACKGROUND):
    """Puts the image on an opaque square of the given size, centred."""
    canvas = Image.new("RGB", size, background)
    fitted = contain(im, size)
    paste(canvas, fitted, ((size[0] - fitted.width) // 2, (size[1] - fitted.height) // 2))
    return canvas


def split_lockup(logo):
    """Cuts the stacked logo into the mark (top) and the wordmark (bottom).

    The logo file holds the triangular mark above the A-DOS wordmark. The two
    are separated by an empty band, and the bands are found rather than
    hard-coded, so the cut survives a new logo.
    """
    alpha = logo.getchannel("A")
    width, height = logo.size
    rows = [any(alpha.getpixel((x, y)) > 8 for x in range(0, width, 4)) for y in range(height)]

    # The filled bands, as (first row, last row).
    bands = []
    start = None
    for y, filled in enumerate(rows):
        if filled and start is None:
            start = y
        elif not filled and start is not None:
            bands.append((start, y - 1))
            start = None
    if start is not None:
        bands.append((start, height - 1))
    if len(bands) < 2:
        raise SystemExit("could not find the two parts in the logo - is resources/a-dos-logo.png the stacked lockup?")

    mark = logo.crop((0, bands[0][0], width, bands[0][1] + 1))
    wordmark = logo.crop((0, bands[1][0], width, bands[-1][1] + 1))
    return mark, wordmark


def make_icon():
    """The store icon: the mark on the brand background, 512x512."""
    mark = load(os.path.join(RESOURCES, "a-dos-icon.png"))
    # The mark carries its own shadow and glow; it is scaled to 92% of the
    # canvas, which is what Play's own icon template does.
    icon = on_background(mark, (ICON_SIZE, ICON_SIZE))
    scaled = contain(mark, (round(ICON_SIZE * 0.92), round(ICON_SIZE * 0.92)))
    paste(icon, scaled, ((ICON_SIZE - scaled.width) // 2, (ICON_SIZE - scaled.height) // 2))
    return icon


def make_feature():
    """The banner: the mark and the wordmark side by side, 1024x500."""
    logo = load(os.path.join(RESOURCES, "a-dos-logo.png"))
    mark, wordmark = split_lockup(logo)

    canvas = Image.new("RGB", FEATURE_SIZE, BACKGROUND)
    width, height = FEATURE_SIZE

    # The mark on the left, the wordmark on the right. The widths are fixed
    # shares of the canvas so the two always fit next to each other.
    mark_fit = contain(mark, (round(width * 0.34), round(height * 0.80)))
    word_fit = contain(wordmark, (round(width * 0.52), round(height * 0.36)))

    mark_x = round(width * 0.05)
    mark_y = (height - mark_fit.height) // 2
    paste(canvas, mark_fit, (mark_x, mark_y))

    word_x = mark_x + mark_fit.width + round(width * 0.04)
    word_y = (height - word_fit.height) // 2
    paste(canvas, word_fit, (word_x, word_y))

    return canvas


def make_screenshot(path):
    """A capture on a 16:9 canvas in the brand colour."""
    shot = load(path)
    canvas = Image.new("RGB", SHOT_SIZE, BACKGROUND)
    fitted = contain(shot, SHOT_SIZE)
    paste(canvas, fitted, ((SHOT_SIZE[0] - fitted.width) // 2, (SHOT_SIZE[1] - fitted.height) // 2))
    return canvas


def render(shots_dir, check):
    os.makedirs(OUT, exist_ok=True)
    written = []

    icon = make_icon()
    feature = make_feature()
    written.append((os.path.join(OUT, "icon-512.png"), icon))
    written.append((os.path.join(OUT, "feature-1024x500.png"), feature))

    for source, target in SHOTS:
        src = os.path.join(shots_dir, source)
        if not os.path.exists(src):
            print(f"skipping {target}: {src} is missing", file=sys.stderr)
            continue
        written.append((os.path.join(OUT, target), make_screenshot(src)))

    failures = 0
    for path, image in written:
        if check:
            if not os.path.exists(path):
                print(f"MISSING {os.path.relpath(path, ROOT)}", file=sys.stderr)
                failures += 1
                continue
            if Image.open(path).tobytes() != image.tobytes():
                print(f"DIFFERS {os.path.relpath(path, ROOT)}", file=sys.stderr)
                failures += 1
        else:
            # 24-bit PNG: the feature graphic and the screenshots must not
            # carry an alpha channel, Play refuses them otherwise.
            image.convert("RGB").save(path, "PNG", optimize=True)
            print(f"wrote {os.path.relpath(path, ROOT)} ({image.width}x{image.height})")

    return failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shots", default=os.path.join(ROOT, "build", "play-shots"),
                        help="where the raw captures live")
    parser.add_argument("--check", action="store_true",
                        help="verify the committed assets instead of writing them")
    args = parser.parse_args()

    failures = render(args.shots, args.check)
    if args.check and failures:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
