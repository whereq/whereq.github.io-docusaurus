package com.whereq.ados

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * The rule that keeps the app usable across launches.
 *
 * DOSBox boots one machine per process and never empties its global device
 * table, so a process that already booted cannot boot again. Android hands the
 * cached process of a finished app back on the next launch, which is how a
 * second launch ends up in a spent process and dies with
 * "DOS:Too many devices added".
 *
 * The process therefore has to end together with the activity.
 */
class ProcessLifetimeTest {

    @Test
    fun `the process ends with the activity once DOSBox has booted`() {
        assertEquals(
            ProcessLifetime.ENDS_WITH_ACTIVITY,
            resolveProcessLifetime(
                activityDestroyed = true,
                dosboxCoreHasBooted = true
            )
        )
    }

    @Test
    fun `a process that never booted DOSBox may stay`() {
        assertEquals(
            ProcessLifetime.SURVIVES,
            resolveProcessLifetime(
                activityDestroyed = true,
                dosboxCoreHasBooted = false
            )
        )
    }

    @Test
    fun `the process stays while the activity is alive`() {
        assertEquals(
            ProcessLifetime.SURVIVES,
            resolveProcessLifetime(
                activityDestroyed = false,
                dosboxCoreHasBooted = true
            )
        )
    }

    @Test
    fun `the instrumented test keeps the process alive`() {
        assertEquals(
            ProcessLifetime.SURVIVES,
            resolveProcessLifetime(
                activityDestroyed = true,
                dosboxCoreHasBooted = true,
                keepProcessForTests = true
            )
        )
    }
}
