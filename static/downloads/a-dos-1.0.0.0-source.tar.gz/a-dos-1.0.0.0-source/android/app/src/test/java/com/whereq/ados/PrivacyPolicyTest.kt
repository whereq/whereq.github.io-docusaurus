package com.whereq.ados

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * The privacy policy, and the link the app gives to it.
 *
 * A-DOS is free and open-source software, but its repository is private - the
 * published source is the archive on the site, not the repository. So its
 * privacy policy cannot live in the repository alone: Google Play wants a
 * policy at a public https URL, and the repository is not one. The policy
 * text therefore lives in the repository at `docs/PRIVACY.md` as the
 * authoritative copy, and it is published as a page on the site - which is
 * the URL the app hands to the browser.
 *
 * A link that points at a file that is not there, or at a policy that says
 * something else than the app does, is worse than no link at all, so the two
 * are checked against each other here: the policy has to exist in the
 * repository, and the URL the app hands to the browser has to be the
 * published page of that policy.
 *
 * This is a JVM test on purpose: it reads the source tree, and the source
 * tree is where the policy lives.
 */
class PrivacyPolicyTest {

    @Test
    fun thePolicyIsInTheRepository() {
        val policy = privacyPolicyFile()
        assertTrue(
            "the privacy policy should be in the repository, at docs/PRIVACY.md",
            policy.isFile
        )

        val text = policy.readText()

        assertTrue(
            "the policy should say that the app collects no data",
            text.contains("does not collect, transmit, share or sell any data")
        )
        assertTrue(
            "the policy should name the package the policy is about",
            text.contains("com.whereq.ados")
        )
        assertTrue(
            "the policy should point at the published source code of the app",
            text.contains(SOURCE_PAGE)
        )
    }

    @Test
    fun theAppLinksToThePublishedPolicy() {
        val url = privacyPolicyUrl()

        // The repository is private, so the policy the app links to is the
        // published page on the site - not a file in the repository.
        assertTrue(
            "the privacy policy link should point at the published policy page, but it is \"$url\"",
            url.startsWith("https://whereq.github.io/docs/privacy/")
        )
        assertTrue(
            "the privacy policy link should name the policy page, but it is \"$url\"",
            url.endsWith("/docs/privacy/a-dos/")
        )
    }

    @Test
    fun theReadmeLinksToThePolicy() {
        val readme = findInRepository("README.md")
        assertTrue("the README should be in the repository", readme.isFile)
        assertTrue(
            "the README should link to the privacy policy",
            readme.readText().contains("docs/PRIVACY.md")
        )
    }

    /* ------------------------------------------------------------------ */

    /**
     * The URL the launcher footer hands to the browser.
     *
     * It is read out of the string resource rather than out of the code, so
     * the test asks the same question the app does: what is in
     * `strings.xml`?
     */
    private fun privacyPolicyUrl(): String {
        val strings = findInRepository("android/app/src/main/res/values/strings.xml")
        assertTrue("the string resources should be in the repository", strings.isFile)
        val text = strings.readText()
        val match = Regex("""<string name="privacy_policy_url"[^>]*>([^<]+)</string>""")
            .find(text)
        assertTrue(
            "strings.xml should carry a privacy_policy_url",
            match != null
        )
        return match!!.groupValues[1]
    }

    /** The privacy policy file in the repository. */
    private fun privacyPolicyFile(): File = findInRepository("docs/PRIVACY.md")

    /**
     * Finds a file in the repository.
     *
     * The repository root is the directory that holds `COPYING` and `VERSION`
     * - the licence and the version file only exist there, so the lookup
     * cannot land on one of the sub-directories that have a README of their
     * own. The unit test's working directory is the module directory or the
     * repository root, depending on how Gradle was started, so the search
     * walks up from wherever it is.
     */
    private fun findInRepository(relative: String): File = File(repositoryRoot(), relative)

    /** The root of the repository. */
    private fun repositoryRoot(): File {
        val roots = generateSequence(File(System.getProperty("user.dir")).absoluteFile) { it.parentFile }
        for (root in roots) {
            if (File(root, "COPYING").isFile && File(root, "VERSION").isFile) {
                return root
            }
        }
        throw AssertionError(
            "could not find the repository root below " + System.getProperty("user.dir")
        )
    }

    companion object {
        /** Where the published source of A-DOS lives. */
        private const val SOURCE_PAGE = "https://whereq.github.io/docs/legal/a-dos-source/"
    }
}
