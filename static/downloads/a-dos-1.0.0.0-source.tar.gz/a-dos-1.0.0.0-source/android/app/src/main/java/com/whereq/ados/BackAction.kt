package com.whereq.ados

/**
 * What one press of the back button should do.
 *
 * The back button is the app's only "undo" gesture, and A-DOS has two things
 * that can be dismissed with it: the game launcher and the on-screen keyboard.
 * When neither is open, the press leaves the app - which is what the back
 * button has always done here.
 *
 * The decision lives in its own file, away from the activity, because it is the
 * part that has to be right: it is the piece that Android 13+ stopped
 * delivering to the activity (see [AdosActivity] and `docs/PLAY-STORE.md`), and
 * it is the piece the regression test checks.
 */
enum class BackAction {

    /** The game launcher is open: close it and stay in the app. */
    CLOSE_LAUNCHER,

    /** The on-screen keyboard panel is up: fold it away and stay in the app. */
    FOLD_KEYBOARD,

    /** Nothing of ours is open: the press leaves the app. */
    FINISH,
}

/**
 * Decides what the back button does, given what is on screen.
 *
 * The launcher wins over the keyboard: it is the larger surface, it is drawn on
 * top of everything, and it has its own Close button, so a back press while it
 * is open is about the launcher and nothing else.
 *
 * @param launcherVisible whether the game launcher is currently on screen
 * @param keyboardPanelVisible whether the on-screen keyboard panel is up
 * @return the action the back press performs
 */
fun resolveBackAction(launcherVisible: Boolean, keyboardPanelVisible: Boolean): BackAction =
    when {
        launcherVisible -> BackAction.CLOSE_LAUNCHER
        keyboardPanelVisible -> BackAction.FOLD_KEYBOARD
        else -> BackAction.FINISH
    }
