package com.whereq.ados

/**
 * How long the app's process may live relative to the activity.
 *
 * DOSBox's native core boots exactly one machine per process. Its globals are
 * never reset between boots - the console devices stay in the global
 * `Devices[]` table (`src/dos/dos_devices.cpp`), and `DOS_SetupDevices()`
 * registers a fresh set on every boot until the ten slots are full, at which
 * point `DOS_AddDevice()` ends the run with "DOS:Too many devices added".
 *
 * Android keeps the process of a finished app around as a *cached* process and
 * hands it back on the next launch. That is how the failure is reached in
 * practice: leave A-DOS with the back button, launch it again, and it comes up
 * broken.
 *
 * The rule that keeps the two in step is therefore: the process ends together
 * with the activity that owns the DOSBox boot. The next launch then starts a
 * fresh process - and a fresh boot - exactly like a game launch does (see
 * `AdosActivity.relaunch()`).
 */
enum class ProcessLifetime {
    /** The process stays; it can still be used for another DOSBox boot. */
    SURVIVES,

    /** The process ends together with the activity. */
    ENDS_WITH_ACTIVITY
}

/**
 * Decides whether the process may outlive the activity.
 *
 * @param activityDestroyed true when the activity is being destroyed.
 * @param dosboxCoreHasBooted true when the DOSBox core has already run in this
 *   process. A process that never booted it could still boot it later, so it
 *   may stay; a process that did boot it cannot boot it a second time.
 * @param keepProcessForTests true to keep the process regardless. Only the
 *   instrumented test needs this: the process kill would take the test runner
 *   down with it.
 */
fun resolveProcessLifetime(
    activityDestroyed: Boolean,
    dosboxCoreHasBooted: Boolean,
    keepProcessForTests: Boolean = false
): ProcessLifetime {
    if (!activityDestroyed) return ProcessLifetime.SURVIVES
    if (keepProcessForTests) return ProcessLifetime.SURVIVES
    if (!dosboxCoreHasBooted) return ProcessLifetime.SURVIVES
    return ProcessLifetime.ENDS_WITH_ACTIVITY
}
