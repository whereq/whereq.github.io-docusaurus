# Publishing A-DOS to Google Play

How to put **A-DOS** (`com.whereq.ados`) on Google Play, starting from the
`v1.0.0.0` release that is already published on GitHub.

Every policy date and requirement below was checked against Google's own
documentation in November 2026. The file paths and line numbers refer to the
tree at tag `v1.0.0.0`.

> **The answers are written out.** This document explains *why* each
> requirement exists and what had to change in the code. The **listing
> itself** — the text to paste into the console, the privacy-policy URL, the
> data-safety answers, the app-content declarations and the asset checklist —
> is in **[`docs/PLAY-CONSOLE.md`](PLAY-CONSOLE.md)**. Keep that one open
> while you are in the Play Console.

---

## 0. Where A-DOS stands today

### Already satisfied

| Requirement | Status |
|---|---|
| `targetSdk 36` | set — `android/app/build.gradle:94` |
| Predictive back | handled with an `OnBackInvokedCallback` — `android/app/src/main/java/com/whereq/ados/AdosActivity.kt` |
| 16 KB page sizes | every `PT_LOAD` segment aligned to `0x4000` — `android/CMakeLists.txt` |
| App Bundle | `bin/build.sh bundle` builds it; CI publishes it next to the APK |
| Privacy policy | published at <https://whereq.github.io/docs/privacy/a-dos/> — the authoritative text is `docs/PRIVACY.md`; see [blocker 5](#5-blocker-5--privacy-policy) |
| GPLv2 obligations | the licence and the notices ship in the app (`LicensesActivity`); the complete source of each build is published — see [blocker 5](#the-open-source-obligations-gplv2) |
| 64-bit ABIs | `arm64-v8a` + `x86_64` — `android/app/build.gradle:22` |
| `compileSdk 36` | already set — `android/app/build.gradle:89` |
| AGP ≥ 8.5.1 (16 KB ZIP alignment) | 8.7.3 — `android/gradle/libs.versions.toml` |
| Uncompressed native libs in the APK | `useLegacyPackaging false` — `android/app/build.gradle:183` |
| Edge-to-edge (Android 15+ mandatory) | already opted in — `AdosActivity.kt:1083` |
| Signing key strength | RSA 2048, valid until 2054-03-29 (Play wants > 2033-10-22) |
| No copyrighted content shipped | the two example bundles are original assembly |
| `versionCode` monotonic | `major·10⁶ + minor·10⁴ + patch·10² + build` — `android/app/build.gradle:38` |

### Still to do in the Play Console

The five blockers below were code changes; they are **done**. What is left is
the console work, which is described in [§7](#7-play-console-setup-step-by-step)
and [§9](#9-timeline):

| # | Remaining | Where |
|---|---|---|
| 1 | Create the app and enrol Play App Signing with the **existing** release key | §6.3 |
| 2 | Store listing, icons, screenshots | §7.2 |
| 3 | App content declarations (privacy policy, data safety, content rating) | §7.3 |
| 4 | The `specialUse` foreground service justification | §7.4 |
| 5 | Closed test → production access → production release | §9 |

Every field of §7 and §7.3 is written out, ready to paste, in
**[`docs/PLAY-CONSOLE.md`](PLAY-CONSOLE.md)**.

The sections below keep the reasoning for each fix, so the next person does
not have to rediscover why the code looks the way it does.

---

## 1. Blocker 1 — target API 36

> **Status: done.** `targetSdk 36` is set in `android/app/build.gradle:94`.

Since **August 31, 2026**, new apps and app updates must target **Android 16
(API level 36)**. The extension window closed on **November 1, 2026**, so
there is no longer a way around it.

`android/app/build.gradle:94`:

```groovy
targetSdk 35      // -> targetSdk 36
```

`compileSdk` is already 36, so no other change is needed for the SDK level
itself.

### What targetSdk 36 changes at runtime

Review the behaviour changes for apps targeting Android 16 before shipping:

* **Predictive back** — see blocker 2. This is the one that breaks A-DOS.
* **Edge-to-edge** — already handled (`AdosActivity.hideSystemUi()` uses
  `WindowCompat.setDecorFitsSystemWindows(window, false)`).
* **16 KB page sizes** — see blocker 3.

---

## 2. Blocker 2 — the back button stops working

> **Status: done.** The app registers an `OnBackInvokedCallback` (API 33+), so
> the back button closes the game launcher, folds the on-screen keyboard away
> and only leaves the app when there is nothing of ours left to dismiss — the
> behaviour it had before Android 13. Covered by a unit test and by an
> instrumented test that presses the real back button on a device.
>
> Leaving the app ends the process as well, so that the next launch starts a
> fresh DOSBox — see [the exit path had a broken launch behind it](#the-exit-path-had-a-broken-launch-behind-it).

For apps targeting API 36, Android **does not call `onBackPressed()` and does
not dispatch `KeyEvent.KEYCODE_BACK`**. Predictive back is enabled by
default.

A-DOS uses the back button in two places, and **both die silently**:

1. `AdosActivity.kt` — folds the virtual keyboard away, closes the game
   launcher:

   ```kotlin
   override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
       if (keyCode == KeyEvent.KEYCODE_BACK) { ... }
       return super.onKeyDown(keyCode, event)
   }
   ```

2. `SDLActivity.java:616` — SDL2's own back handling, which honours the
   `SDL_ANDROID_TRAP_BACK_BUTTON` hint.

After the bump, pressing back on Android 16 exits the app instead of folding
the keyboard away. There is no crash and no warning — it just stops working.

### The fix — an `OnBackInvokedCallback`

`SDLActivity` extends plain `android.app.Activity` and `androidx.activity` is
not a dependency, so `OnBackPressedDispatcher` is not available without
rewriting SDL2's Java base class. The platform API is, though — an
`OnBackInvokedCallback` registered on API 33+:

```kotlin
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
    getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
        OnBackInvokedDispatcher.PRIORITY_DEFAULT
    ) {
        if (!closeLauncher() && !foldKeyboard()) finish()
    }
}
```

That is what upstream SDL2 did for the same problem
(`libsdl-org/SDL#16052`).

This is what the app does, in `AdosActivity`:

* `registerBackInvokedCallback()` registers the callback in `onCreate` and
  unregisters it in `onDestroy`.
* `handleBack()` runs the **one** decision — close the launcher, else fold the
  keyboard, else let the press leave the app — and it is shared by all three
  paths: the predictive-back callback (API 33+), `onKeyDown()` (the legacy key
  event, Android 12 and older) and `onBackPressed()` (the legacy system back).
* The decision itself lives in `BackAction.kt` as `resolveBackAction()`, away
  from the activity, so it can be tested without a device.

The manifest no longer carries `android:enableOnBackInvokedCallback="false"`.
Predictive back stays on, and the app answers it.

The trade-off is the animation: the system plays "back to home" while the app
is leaving, which looks odd over a DOS text screen. In exchange the back
button works again, which is worth more than the animation.

### What the device test found

Measured on the `Medium_Phone_API_37.0` emulator (Android 17, API 37, x86_64)
with `android/run-emulator.sh`, against three builds:

| Build | BACK pressed | Result |
|---|---|---|
| Published **1.0.0.0** (`targetSdk 35`, no opt-out) | launcher open | launcher stays open, app stays in the foreground |
| This branch **without** any back handling (`targetSdk 36`) | launcher open | **the app is dismissed** — the launcher app comes to the front |
| This branch **with** the callback (`targetSdk 36`) | launcher open | **the launcher closes**, the app stays in the foreground |

The first row is the pre-existing defect: on API 33+ the back key never
reaches `Activity.onKeyDown` for this app — SDL2's surface takes it — so
neither "close the launcher" nor "fold the keyboard" fired, on the published
build either. The second row is what `targetSdk 36` would have made worse: the
press would throw the player out of the app entirely.

The third row is the fix.

### The exit path had a crash in it

With the callback in place, the back button reaches the last step — leaving
the app — and that step aborted the process:

```
Fatal signal 6 (SIGABRT) ... in tid ... (SDLThread)
Abort message: 'terminating due to uncaught exception of type char*'
    #06 Section_prop::~Section_prop()
    #08 Config::~Config()
    #09 SDL_main()
```

A DOSBox destroy function fails while the emulator is being torn down and calls
`E_Exit`, which throws the error message as a `char*`. An exception that
escapes a destructor calls `std::terminate`, so the app died with an abort
while it was only shutting down. `src/misc/setup.cpp` catches it now and
prints it instead; the teardown continues and the app exits cleanly. The
message it prints names the failure:

```
TEARDOWN: Could not set windowed video mode 640x400-16: Invalid window
```

The video mode is set while the emulator is being torn down, which is already
too late — the window is gone — so the failure is expected and only the abort
was not. The same line shows up when a DOSBox instance is torn down at
start-up, which is the other place the teardown runs.

This was latent before: the app only ever left through `relaunch()`, which
kills the process outright (`Runtime.getRuntime().exit(0)`), so the native
teardown never ran. Finishing the activity runs it.

### The exit path had a broken launch behind it

With the abort out of the way the exit itself worked — but the **next** launch
did not. Leaving the app with the back button and starting it again gave:

```
Exit to error: DOS:Too many devices added
```

The app came up unusable: the activity was created and closed again, and the
screen stayed black.

The cause is in the native core, not in the app layer. DOSBox's `main()` boots
**one** machine per process, and its globals are never reset between boots:

* `src/dos/dos_devices.cpp:34` — `DOS_Device * Devices[DOS_DEVICES]` — a global
  table with ten slots (`include/dos_inc.h:78`).
* `DOS_SetupDevices()` (`:186`) registers CON, NUL and LPT1 on **every** boot,
  on top of the serial port and the EMS device.
* `DOS_AddDevice()` (`:161`) fills the table and ends the run with
  `E_Exit("DOS:Too many devices added")` (`:171`) once the ten slots are used.
* Nothing empties the table: `DOS_DelDevice()` (`:174`) is only called for an
  explicit device delete, and `DOS_ShutDown()` (`src/dos/dos.cpp:1266`) only
  does `delete test`.

So a second boot in the same process finds the table full, and DOSBox ends the
run with that error.

Android is what makes it reachable. A finished app's process is not killed: it
is kept as a **cached** process and handed back on the next launch — exactly the
process that already booted DOSBox. Reproduced from scratch on the API 37
emulator:

```
am force-stop com.whereq.ados   # a clean slate
am start   ...                   # boots, pid 4374
input keyevent 4                 # leaves the app — the process survives
am start   ...                   # lands in pid 4374 → "DOS:Too many devices added"
```

Before the teardown fix this was masked: the process died with SIGABRT on every
exit, so there was never a second boot.

### The fix — the process ends with the activity

The app already had the right model for this: a game launch tears the process
down and starts a new one (`relaunch()` → `Runtime.getRuntime().exit(0)`),
because the machine lives in RAM and cannot be handed over to another process.
The exit path now uses the same model:

* `AdosActivity.onDestroy()` ends the process, 200 ms later, so the transition
  to the next app can still be drawn.
* The rule lives in `ProcessLifetime.kt` as `resolveProcessLifetime()`, away
  from the activity, and is covered by a unit test.
* The instrumented test switches the process kill off
  (`AdosActivity.keepProcessForTests`), because the test runner lives in the
  same process and would die with it.

What that means in practice: **the process lives exactly as long as the
activity.** Leaving the app ends the process, and the next launch starts a
fresh one and a fresh DOSBox. Going to the background does *not* end it — the
process keeps the running machine, which is what the foreground service is for
([§7.4](#74-foreground-service-declaration)).

Measured on the `Medium_Phone_API_37.0` emulator after the fix:

| Step | Result |
|---|---|
| launch | boots to the `C:\>` prompt — pid 5568 |
| back, launcher open | the launcher closes, the app stays in the foreground, the process stays |
| home, then back to the app | the **same** pid — the machine is still running |
| back, nothing open | the app leaves and the process is gone (`pidof` is empty) |
| launch again | a **new** pid (5693) and a normal boot — no "Too many devices added" |
| the same cycle once more | the same result, twice in a row |

The log of the exit is clean:

```
TEARDOWN: Could not set windowed video mode 640x400-16: Invalid window
VM exiting with result code 0, cleanup skipped.
Process com.whereq.ados (pid 5693) has died
```

No `FATAL EXCEPTION`, no `SIGABRT`, and the crash buffer stays empty.

### The tests

| Test | What it covers | How to run it |
|---|---|---|
| `BackActionTest` (JVM) | the decision: the launcher wins over the keyboard, the keyboard folds, the press leaves the app when nothing is open; and the manifest must not opt out of predictive back | `./android/gradlew --project-dir android :app:testDebugUnitTest` |
| `ProcessLifetimeTest` (JVM) | the process-lifetime rule: the process ends with the activity, a process that never booted DOSBox may stay, and the instrumented test may keep it | `./android/gradlew --project-dir android :app:testDebugUnitTest` |
| `BackHandlingTest` (instrumented) | the real thing on API 33+: a system back press closes the launcher and keeps the app alive, and leaves the app when there is nothing to close | `./android/gradlew --project-dir android :app:connectedDebugAndroidTest` (or `android/run-emulator.sh instrument`) |

CI runs the unit tests on every pull request. The instrumented test needs an
emulator on API 33 or newer, so CI does not run it — it is run by hand against
`Medium_Phone_API_37.0` with `android/run-emulator.sh instrument`.

The instrumented test is what caught the shutdown crash: it is the only test
that finishes the activity, and the activity finishing is what tears the
emulator down. It cannot check the process kill itself — the runner lives in
the process that is killed — so that part is verified on the emulator by hand,
as in the table above.

---

## 3. Blocker 3 — 16 KB page sizes

> **Status: done.** The linker flags are in `android/CMakeLists.txt`; all
> three ABIs now report `0x4000` for every `PT_LOAD` segment, and CI fails
> the build if that ever changes.

Apps targeting **API 35 or higher** must support **16 KB memory page sizes**
on 64-bit devices. A-DOS ships three native libraries, so this applies to the
`arm64-v8a` and `x86_64` variants.

The libraries built by CI at `v1.0.0.0` are **4 KB aligned**:

```
$ readelf -lW libdosbox.so | grep LOAD
  LOAD  0x000000 ... R E 0x1000
  LOAD  0x4c9c90 ... RW  0x1000
  LOAD  0x4deef8 ... RW  0x1000
```

`0x1000` is 4 KB. Play requires every `PT_LOAD` segment to have
`p_align >= 0x4000` (16 KB). The APK packaging side is already correct (AGP
8.7.3 ≥ 8.5.1, uncompressed native libs), so only the ELF side needs work.

### Fix — add the linker flags

The project builds with **NDK 27.1.12297006** (`.github/workflows/ci.yml`).
NDK r27 and older do **not** align to 16 KB by default; only r28 and newer
do. Two options:

**Option 1 — stay on NDK 27, add the linker flags** (smallest change):

In `android/build-android.sh` (the CMake link for `libdosbox.so`) and in
`android/build-sdl2.sh` (the SDL2 static libraries), add:

```
-Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384
```

**Option 2 — move to NDK r28+**, where 16 KB alignment is the default:

```yaml
# .github/workflows/ci.yml
sdkmanager "... ndk;28.0.13004108"
```

Option 2 is cleaner, but it changes the toolchain for the whole native build,
so it deserves a full rebuild and a retest. Option 1 is a two-line change
with the same result. **Either is fine — what matters is that the flags land
on every native link, SDL2 included**, because `libdosbox.so` statically
links `libSDL2.a` and inherits its alignment.

### Verify before uploading

```sh
# 1. ELF alignment of every 64-bit library
readelf -lW build/android/arm64-v8a/libdosbox.so | grep LOAD
#    every LOAD must show 0x4000, not 0x1000

# 2. ZIP alignment of the packaged app
$ANDROID_SDK_ROOT/build-tools/36.0.0/zipalign -v -c -P 16 4 app-release.apk
#    must end with "Verification successful"

# 3. The bundle's alignment config
bundletool dump config --bundle=app-release.aab | grep alignment
#    must show PAGE_ALIGNMENT_16K
```

---

## 4. Blocker 4 — build an App Bundle

> **Status: done.** `bin/build.sh bundle` builds the bundle, and
> `.github/workflows/release.yml` publishes `a-dos-<version>.aab` next to the
> APK.

Play requires an **Android App Bundle** for new apps. APKs are no longer
accepted for new listings.

The Gradle module already supports it — `android/app/build.gradle:11`
documents `./gradlew bundleRelease` — but `bin/build.sh` has no `bundle`
target, and the CI workflow builds APKs only.

### Add a `bundle` target to `bin/build.sh`

Mirror `do_apk()` (`bin/build.sh:146`) with a `do_bundle()` that runs
`bundleRelease` and copies
`android/app/build/outputs/bundle/release/app-release.aab` into
`build/bundle/`.

### Add an AAB job to CI

Add a `bundle` job to `.github/workflows/release.yml` that runs
`./android/gradlew --project-dir android :app:bundleRelease` and uploads
`app-release.aab` as an artifact, so the Play upload can be produced by the
same tag that produced the GitHub APK. The AAB must be signed with the
**upload key** (see §6).

---

## 5. Blocker 5 — privacy policy

> **Status: done.** The policy is published as a page on the public WhereQ
> site — <https://whereq.github.io/docs/privacy/a-dos/> — and the launcher's
> footer links the same URL. The authoritative text lives in `docs/PRIVACY.md`
> in this repository and is published verbatim; the app also carries a
> licence screen with the GPL text and the attribution, and the complete
> source of the build is published next to the policy. See
> [the open-source obligations](#the-open-source-obligations-gplv2) below.

**Every app needs a privacy policy, even one that collects nothing.** A-DOS
collects nothing: no network code, no analytics, no SDKs beyond AndroidX and
Kotlin coroutines. The Data safety form is still mandatory and its answers
must match the policy.

Requirements Play enforces:

* Hosted on an **active, public, non-geofenced `https://` URL** — not a PDF,
  not a downloadable file, not editable.
* Accessible worldwide, with no login.
* Titled with "privacy policy" in the name.
* Names the app (**A-DOS**) or the developer entity shown in the store
  listing.
* Includes a contact point for inquiries, and states that no data is
  collected, shared or sold, plus a retention/deletion statement.
* **Also linked inside the app** — "a privacy policy link or text within the
  app itself". The launcher's footer carries it.

### Where the policy is hosted

The policy is published on the **WhereQ site** (`whereq.github.io`), the
project's public documentation hub:

```
https://whereq.github.io/docs/privacy/a-dos/
```

That page is a Docusaurus page — a standard, non-editable web page served
over HTTPS with a valid certificate, open to anyone, no login and no
geofencing. It is the exact text of `docs/PRIVACY.md`, which stays the
authoritative copy in this repository. The app's footer link
(`R.string.privacy_policy_url`) and the Play listing both name that URL.

The site is a separate repository (`whereq/whereq.github.io-docusaurus`,
published to the `whereq/whereq.github.io` Pages repo); the page lives in
`docs/privacy/a-dos.md` there and is released with `./bin/whereq.sh all`.

Do **not** use `https://www.whereq.com/docs/privacy/a-dos` for the Play
listing. The apex domain `whereq.com` hosts the WhereQ map app — a
different project, with nothing to do with A-DOS — and `www.whereq.com/docs/...`
redirects to that app's shell, which answers HTTP 200 with an unrelated
single-page app rather than with the policy. Play's reviewer would see the
wrong page.

**Check the URL before the Play submission, every time.** The listing and
the in-app link have to name the same URL, and it has to be open to the
reviewer:

```sh
url="https://whereq.github.io/docs/privacy/a-dos/"
curl -sL -o /dev/null -w '%{http_code} %{url_effective}\n' "$url"
curl -sL "$url" | grep -c "Privacy Policy"
```

The first line must be `200` with the URL you expect, and the second must
print a number greater than zero — and both must hold **without** being
logged in, because that is how the reviewer sees it.

Note that the Play listing must name the same entity as the policy — if the
store listing says "WhereQ" the policy has to say WhereQ too.

### The open-source obligations (GPLv2)

A-DOS embeds the DOSBox core, which is **GPLv2**, so the app is a GPLv2
work. That carries two obligations that have nothing to do with the listing,
and both are met now.

**1. The licence and the notices travel with the program.** GPLv2 section 2
asks for a copy of the licence along with the program and for the copyright
notices to be kept intact. The shipped APK used to carry neither: there was
no licence text, no `NOTICE` and no about screen. Now:

* `COPYING` (the GPLv2 text) and `NOTICE` (the DOSBox attribution, the
  Em-DOSBox provenance and the SDL2 notice) are bundled as assets —
  `android/app/src/main/assets/`.
* `LicensesActivity` shows them, together with the summary and the link to
  the source. It is reachable from the launcher's footer, next to the
  privacy link.

**2. Everyone who receives the program receives its source.** GPLv2
section 3 asks for the complete corresponding source to accompany the
binary, or a written offer. The public predecessor repository
[`whereq/whereq-dosbox`](https://github.com/whereq/whereq-dosbox) already
carries the DOSBox core, the JNI glue and the build scripts under GPLv2,
but A-DOS has diverged: 17 core files (including `src/gui/sdlmain.cpp` and
`src/misc/setup.cpp`) and the whole Android application layer differ.

So the complete source of each build is published as a snapshot:

```
https://whereq.github.io/downloads/a-dos-1.0.0.0-source.tar.gz
```

The snapshot is the tree of the release commit plus a `SOURCE-RELEASE.md`
that names the version, the commit and the build. The page that documents it
— <https://whereq.github.io/docs/legal/a-dos-source/> — carries the checksum
of the archive and the licence of every part. The in-app licence screen
links to that page.

SDL2 is **zlib**-licensed, so its notice has to travel with the binary but
not its source; `third_party/fetch-sdl2.sh` pins the exact release the build
uses (2.30.0) and the `NOTICE` carries its notice.

---

## 6. Accounts, keys and identity

### 6.1 Play Console account

Create the account at <https://play.google.com/console> ($25, one time).

The account type decides your timeline:

| Account type | Closed-test requirement |
|---|---|
| **Personal**, created **after Nov 13, 2023** | **12 testers opted in continuously for 14 days**, then apply for production access |
| Personal, created before Nov 13, 2023 | none |
| **Organisation** (needs a D‑U‑N‑S number) | none |

If A-DOS goes out under a new personal account, budget **4–6 weeks** from
your first click to a public listing: the closed test alone is 14 days, and
Google's three reviews (closed track, production-access application,
production release) each take up to about a week.

### 6.2 Android developer verification

Since **September 30, 2026**, apps installed from participating stores on
certified devices must be registered by a verified developer — live in
Brazil, Indonesia, Singapore and Thailand, expanding globally in 2027.

Play developers are registered automatically once identity verification is
complete in Play Console. Check **Play Console → your app → verification
status**. Because A-DOS is distributed on Google Play, use the Play Console
account — no separate Android Developer Console registration is needed.

### 6.3 Play App Signing

Play App Signing is **mandatory for new apps**. It uses two different keys:

| Key | Held by | Purpose |
|---|---|---|
| **Upload key** | you | signs the `.aab` you upload; Play uses it to verify your identity. Google can reset it for you if lost. |
| **App signing key** | Google Play | signs the APKs users install. Google generates RSA 4096, or you upload your own. |

Two ways to enrol, and the right choice depends on what you want:

**A. Let Google generate the app signing key** (the default). Nothing to do;
your existing key becomes the *upload* key. The Play-installed app then has a
different certificate from the GitHub APK — the app installed from Play and
the app installed from the GitHub release are **two different apps** as far
as Android is concerned, even though the package name is the same. Actually
they are the same package name, so the second install **replaces** the first
and the user loses their data. This is the important part: you cannot ship a
Play build with a different certificate and keep the GitHub-installed app
updating in place.

**B. Upload the existing `whereq` release key as the app signing key.** Then
the Play build carries the same certificate (`b16b480d5a1ff…`) as the GitHub
APK, and a user who installed `a-dos-1.0.0.0.apk` from GitHub can update in
place to the Play version without uninstalling. This is what the key exists
for, it satisfies every Play requirement (RSA 2048, valid to 2054), and it
keeps one signing identity across GitHub and Play.

**Take Option B.** It is what `release.yml` already assumes (it pins that
exact fingerprint), and it preserves users' save states and the durable
saves folder across the move to Play.

To do it: Play Console → **App integrity → App signing** → *Choose to use your
own key*, then upload `release.keystore` and the alias `whereq`. The
fingerprint must be the one `release.yml` pins:
`b16b480d5a1ff6d35baff0b15fa3fc4b0ee815e500861fbff1b062c9bf7d3933`.

If the upload key is lost, Play can reset it. If an app signing key *you*
manage is lost, it cannot be reset — back it up with its password, as
`BUILDING.md` already says.

---

## 7. Play Console setup, step by step

### 7.1 Create the app

**Create app** → name *A-DOS*, default language *English (United States)*,
app or game → **App**, free, **declare the app contains no ads**.

Package name: `com.whereq.ados` — this is already fixed in
`android/app/build.gradle:92` and cannot be changed later.

### 7.2 Store listing

**Grow → Store presence → Main store listing** — the exact text to paste is in
[`docs/PLAY-CONSOLE.md`](PLAY-CONSOLE.md) §2.

* **App name** — `A-DOS` (max 30 chars).
* **Short description** — max 80 chars.
* **Full description** — max 4000 chars.
* **App icon** — 512×512 PNG, 32-bit, no alpha.
* **Feature graphic** — 1024×500 PNG or JPEG, no alpha.
* **Phone screenshots** — at least 2, 16:9 or 9:16, each side 320–3840 px.
* **Privacy policy URL** — from blocker 5.

The three assets are generated and ready, in `resources/play/`:

| Asset | File | Geometry |
|---|---|---|
| App icon | `resources/play/icon-512.png` | 512×512 RGB |
| Feature graphic | `resources/play/feature-1024x500.png` | 1024×500 RGB, no alpha |
| Screenshots | `resources/play/screenshot-0{1..4}-*.png` | 1920×1080 RGB |

`android/make-play-assets.py` renders them from the brand files in
`resources/` and the device captures in `build/play-shots/`; `--check` proves
that the committed assets still match a fresh render. The screenshots are
exported to 16:9 because a phone capture is 20:9, and Play rejects a ratio
outside 16:9–9:16.

Write the description around what the app *is*: a DOS emulator for Android
with an on-screen keyboard, save states, and a bundle launcher. Say plainly
that **the app contains no games and no copyrighted software — the user
supplies their own legally obtained DOS programs.** That sentence is what
keeps the listing clean under the IP policy (§8).

### 7.3 App content declarations

All under **Policy and programs → App content**:

| Declaration | Answer for A-DOS |
|---|---|
| **Privacy policy** | the URL from §5 |
| **Ads** | "No ads" |
| **App access** | all features are available without a login; give the reviewer a short instruction set and the example bundle, published at <https://whereq.github.io/downloads/a-dos-demo-bundle.zip> (`whereq-demo-bundle.zip` in `examples/game-bundle/dist/`), so they can see the app running without supplying their own software |
| **Content ratings** | the IARC questionnaire — answer that the app itself ships no games; if asked, note that user-supplied software is not distributed by the app |
| **Target audience and content** | 13+ / general audience, not directed at children — so the Families policy does not apply |
| **Data safety** | "No data collected", "No data shared"; encryption in transit and deletion-request questions are N/A |
| **Government apps** | no |
| **Financial features** | no |
| **News** | no |
| **COVID-19 contact tracing** | no |
| **Health apps** | no |

### 7.4 Foreground service declaration

The app runs a foreground service typed `specialUse`
(`AndroidManifest.xml:79-86`) to keep the emulator alive while the player
switches apps. Since Android 14, Play requires a written justification for
`specialUse` in the Play Console, and reviews it. Use the text already in the
manifest:

> Keeps the DOS emulator and the running game resident so the player can
> switch to another app and return to the exact game state; DOSBox has no
> save-state.

The `POST_NOTIFICATIONS` permission is declared and requested at runtime for
API 33+ — fine, no declaration needed for a normal permission.

### 7.5 Upload the first bundle

**Test and release → Production → Create new release**, then upload the
`.aab`.

Checks the Console will run:

* `targetSdk` ≥ 36 — passes after §1.
* 16 KB page size — passes after §3.
* `versionCode` higher than any previous version — `1000000` for `1.0.0.0`.
* Signature matches the enrolled upload key.
* All three ABIs present in the bundle.

---

## 8. Policy notes specific to A-DOS

**Emulators are allowed on Play.** Several are listed today. What the policy
forbids is shipping or helping to obtain copyrighted content. A-DOS ships no
games, no ROMs and no DOS software, and downloads nothing at all — the user
picks their own files through the system file picker. Keep it that way: the
example bundles in `examples/*/dist/` are original assembly written for this
project and are safe to reference in the listing.

**The "no downloaded executable code" rule.** Play forbids apps that
download executable code (dex, JAR, `.so`) from outside Play. The exemption
is code that runs inside a virtual machine or interpreter. DOS `.COM`/`.EXE`
programs run inside the DOSBox emulator, which is exactly that case, and
A-DOS itself never downloads anything. Describe it plainly in the listing —
it is worth one sentence, because a reviewer seeing an emulator that
executes binaries will look for this.

**"Apps that provide access to other apps, games, or software without
installation"** are subject to additional policy review. A-DOS provides
access to user-supplied software without installation, so expect a question
about it. The answer: the app distributes no software, provides no catalogue
of downloadable games, and never transmits anything.

**The `application/zip` intent filter** (`AndroidManifest.xml:64`) lets a
user open a `.zip` bundle from a file manager. That is a normal, disclosed
capability — mention it in the description so the reviewer sees it.

---

## 9. Timeline

| Stage | Time |
|---|---|
| Fix blockers 1–4, build and verify a signed AAB | 1–3 days |
| Privacy policy page, store listing assets | 1–2 days |
| Closed-test release approved by Google | up to 7 days |
| Recruiting and enrolling 12 testers | 3–7 days (parallel) |
| The 14-day closed test | 14 days |
| Production-access application reviewed | up to 7 days |
| Production release reviewed and rolled out | up to 7 days |
| **Total** | **4–6 weeks** on a new personal account |

Once production access is granted, it does not have to be repeated for later
updates — those go straight to production.

---

## 10. Checklist

**Code** — all done in this branch

- [x] `targetSdk 36` — `android/app/build.gradle:94`
- [x] Predictive back handled with an `OnBackInvokedCallback` (API 33+) —
      `AdosActivity.kt`; the manifest does not opt out
- [x] 16 KB linker flags on the native link — `android/CMakeLists.txt`
- [x] `readelf` shows `0x4000` on every `PT_LOAD` of all three ABIs
- [x] `zipalign -c -P 16 4` passes on the packaged app
- [x] `bin/build.sh bundle` target added; the AAB is published next to the APK
- [x] Privacy policy written (`docs/PRIVACY.md`) and linked from the launcher's
      footer
- [x] Device test on an API 37 emulator: the footer fits, the privacy link
      opens the browser, and BACK closes the launcher instead of throwing the
      player out of the app
- [x] The "back folds the keyboard / closes the launcher" defect on API 33+
      fixed, with a unit test and an instrumented test that presses the real
      back button
- [x] The shutdown abort that the back button ran into — a DOSBox destroy
      function throwing out of a destructor — fixed in `src/misc/setup.cpp`

**Console**

- [ ] Play Console account created; type (personal / organisation) noted
- [ ] Identity verification completed (developer verification, Sept 30, 2026)
- [ ] App created with package `com.whereq.ados`
- [ ] Play App Signing: **own app signing key uploaded**, fingerprint `b16b480d…`
- [ ] Store listing complete, icon 512×512, ≥ 2 phone screenshots
- [ ] Privacy policy reachable at a public https URL, naming A-DOS / WhereQ
      — needs the repository to be public, or the policy on a public host
      (§5)
- [ ] Data safety: "No data collected", "No data shared"
- [ ] Content rating questionnaire done
- [ ] `specialUse` foreground service justification written
- [ ] App access instructions for the reviewer, including the demo bundle

**Release**

- [ ] 12 testers opted in (personal account) — recruit extra to absorb dropouts
- [ ] 14 days elapsed with no tester opting out
- [ ] Production access applied for and approved
- [ ] Closed track uploaded with `versionCode` `1000000`
      (`a-dos-1.0.0.0.aab`)
- [ ] AAB uploaded to production with `versionCode` `1000001`
      (`a-dos-1.0.0.0-vc1000001.aab`); Play-generated APKs verified on a device
- [ ] Confirm the Play build installs **over** the GitHub-installed app (same certificate)

---

## Sources

* [Target API level requirements](https://support.google.com/googleplay/android-developer/answer/11926878)
* [Meet Google Play's target API level requirement](https://developer.android.com/google/play/requirements/target-sdk)
* [Behaviour changes: apps targeting Android 16](https://developer.android.com/about/versions/16/behavior-changes-16)
* [Add support for the predictive back gesture](https://developer.android.com/guide/navigation/custom-back/predictive-back-gesture)
* [Support 16 KB page sizes](https://developer.android.com/guide/practices/page-sizes)
* [Prepare your apps for Google Play's 16 KB page size requirement](https://android-developers.googleblog.com/2025/05/prepare-play-apps-for-devices-with-16kb-page-size.html)
* [Use Play App Signing](https://support.google.com/googleplay/android-developer/answer/9842756)
* [Android App Bundle FAQ](https://developer.android.com/guide/app-bundle/faq)
* [App testing requirements for new personal developer accounts](https://support.google.com/googleplay/android-developer/answer/14151465)
* [Android developer verification](https://developer.android.com/developer-verification)
* [User Data policy](https://support.google.com/googleplay/android-developer/answer/10144311)
* [Prepare your app for review](https://support.google.com/googleplay/android-developer/answer/9859455)
* [Developer Program Policy](https://support.google.com/googleplay/android-developer/answer/18265346)
* [Intellectual Property policy](https://support.google.com/googleplay/android-developer/answer/9888072)
