# Hand-off: the interrupt and mouse work

**Date:** 19 November 2026
**From:** the WhereQ-DOSBox work (the public port)
**To:** this repository

While documenting the interrupt layer in the public port, four things came up
that bear on this tree. This document lists them, says plainly which are
defects and which are not, and gives the exact change for each.

Every `path:line` below is against **this** repository at its current `main`.

---

## 1. The "long-press" right button — a documentation error, already fixed elsewhere, nothing to do here

**Summary: nothing to change in this repository.** The error was in a document
written for the other project, and it has already been corrected there.

The truth about the right button:

> A DOS mouse has two buttons and a touchscreen has one. This app delivers the
> right button in exactly **two** ways: a **second finger** on the picture, and
> the on-screen **RMB** key. There is **no long-press gesture**.

That is what the code does. `android_handle_touch()`
(`src/gui/sdlmain.cpp:2641`) handles three event types, and only two of them
touch the right button:

```
  SDL_FINGERDOWN   →  a second finger joins: Mouse_ButtonPressed(1)
                      src/gui/sdlmain.cpp:2677
  SDL_FINGERUP     →  that finger lifts:    Mouse_ButtonReleased(1)
                      src/gui/sdlmain.cpp:2689
```

The RMB key takes the other route. It pushes a real `SDL_MOUSEBUTTONDOWN` for
`SDL_BUTTON_RIGHT` through the JNI bridge
(`android/jni/dosbox_android.cpp:359-386`), and the event travels
`SDL_PushEvent` → `GFX_Events()` → `HandleMouseButton()` →
`Mouse_ButtonPressed(1)` (`src/gui/sdlmain.cpp:2542-2544`).

There is **no long-press detector** anywhere in the Android layer: no
`OnLongClickListener`, no `postDelayed`, no gesture timer. The on-screen
keyboard's own long-press behaviour, if any, is a keyboard concern and never
reaches the mouse driver.

**Where the false claim was.** In the user guide written for the **public
port** (`docs/USER-GUIDE.md`) and in the two site posts derived from it, one
sentence said that a long-press on the screen does the same as the right
button. It does not. Those documents are fixed in the public port
(`e413070`) and on the docs hub (`d309868`).

**This repository is clean.** `grep -rn "long-press" --include="*.md" .`
returns nothing outside this document, and `README.md` describes the two real
mechanisms correctly (lines 87, 231-232).

**Action: none.** If a user guide is ever written for this app, the right
button is a second finger or the RMB key — nothing else.

---

## 2. The change table in §1.3 omits `src/ints/mouse.cpp`

**Summary: a documentation defect, and it is worth fixing here.**

`docs/TECHNICAL-REFERENCE.md` §1.3 opens with:

> "The vendored tree is the em-dosbox fork of DOSBox r4305, imported
> verbatim. Everything the port added is listed here — this is the complete set
> of changes to `src/` and `include/` relative to the import, so a reviewer can
> bound the blast radius."

It is not the complete set. `src/ints/mouse.cpp` is missing from the table,
and that file carries a lot: the right button, the whole mouse save state, the
stable-configuration / volatile-state split, and the cursor-mask
re-derivation.

In **this** repository the mouse work arrived inside the squashed initial
release `fd78113`, so `git log -- src/ints/mouse.cpp` shows one commit and
nothing else — the change table is the *only* place a reviewer would learn
that this file was touched at all.

**Action: add one row** to the §1.3 table, after the `src/hardware/timer.cpp`
row:

| File | Change | Why |
|---|---|---|
| `src/ints/mouse.cpp` | `MOUSE_StateSize/SaveState/LoadState` over a `MouseStateBlock` holding only the driver's stable configuration; the volatile event queue, the click counters and the `in_UIR` re-entrancy flag are reset on load, never restored | the INT 33h driver's state lives outside guest memory, so a restored game loses its event callback (AX=0Ch) and its custom cursor (AX=09) — the cursor still moves but the clicks stop reaching the game (§5.5) |

While you are there, soften the sentence that calls the table "the complete
set", so the document is accurate about its own scope again.

---

## 3. The RMB key does nothing if `autolock=true`

**Summary: a real code defect, conditional on a non-default setting. Worth
fixing.**

The on-screen RMB key does not reach the mouse driver directly — it pushes an
SDL event, and that event goes through `HandleMouseButton()`. The function
opens with a short-circuit:

```c
static void HandleMouseButton(SDL_MouseButtonEvent * button) {
	switch (button->state) {
	case SDL_PRESSED:
		if (sdl.mouse.requestlock && !sdl.mouse.locked) {
			GFX_CaptureMouse();
			// Don't pass click to mouse handler
			break;
		}
```
`src/gui/sdlmain.cpp:2526-2533`

`requestlock` is set from `autoenable`:

```c
	if (sdl.mouse.autoenable) sdl.mouse.requestlock=enable;
```
`src/gui/sdlmain.cpp:2510`

and `autoenable` is the **`autolock` config option**, verbatim:

```c
    sdl.mouse.autoenable=section->Get_bool("autolock");
```
`src/gui/sdlmain.cpp:2207`

The shipped configuration sets `autolock=false`
(`android/app/src/main/assets/dosbox.conf:29`), so `autoenable` is false,
`requestlock` is never set, and the RMB key works. **But `autolock` is a
user-editable option, and on Android it has no meaning at all** — there is no
mouse to capture. If it is ever set to true, then:

1. the guest calls INT 33h AX=0000h / 0001h / 000Ch, which calls
   `Mouse_AutoLock(true)` and sets `requestlock`;
2. the RMB key pushes the event;
3. `HandleMouseButton()` sees `requestlock && !locked`, calls
   `GFX_CaptureMouse()` and **drops the click**;
4. `GFX_CaptureMouse()`'s Android branch only unlocks the mouse and returns
   (`src/gui/sdlmain.cpp:1501`) — so nothing happens, and the user gets a dead
   key with no feedback at all.

The **second finger is unaffected**, because `android_handle_touch()` calls
`Mouse_ButtonPressed(1)` directly and never goes through
`HandleMouseButton()` (`src/gui/sdlmain.cpp:2677`). The failure is therefore
inconsistent: one right-click mechanism dies, the other keeps working.

**The fix.** `autolock` is a desktop concept. On Android the mouse is never
captured, so `autoenable` should be forced off regardless of the config:

```c
    // Android: there is no mouse to capture, so `autolock` is meaningless
    // here. Leaving autoenable on would make HandleMouseButton() swallow the
    // injected RMB event - it would take the requestlock branch and drop the
    // click - so force it off on every platform with no real mouse.
#if defined(__ANDROID__)
    sdl.mouse.autoenable = false;
#else
    sdl.mouse.autoenable = section->Get_bool("autolock");
#endif
```
at `src/gui/sdlmain.cpp:2207`.

**Alternative, if you would rather not touch the config path:** make the
injected event bypass the short-circuit — tag the pushed event, or have the
JNI path call `Mouse_ButtonPressed(1)` / `Mouse_ButtonReleased(1)` directly.
That is a bigger change; the config one-liner is the smaller and safer fix.

---

## 4. INT 33h AX=0017h can overwrite host pointers

**Summary: an upstream defect, present in this tree. Low severity, but the
fix is a few lines and the pattern already exists in the same file.**

AX=0016h ("save driver state") writes the **entire host struct** into guest
memory:

```c
    case 0x16: /* Save driver state */
		{
			LOG(LOG_MOUSE,LOG_WARN)("Saving driver state...");
			PhysPt dest = SegPhys(es)+reg_dx;
			MEM_BlockWrite(dest, &mouse, sizeof(mouse));
		}
```
`src/ints/mouse.cpp:1009-1015`

and AX=0017h reads it straight back:

```c
    case 0x17: /* load driver state */
		{
			LOG(LOG_MOUSE,LOG_WARN)("Loading driver state...");
			PhysPt src = SegPhys(es)+reg_dx;
			MEM_BlockRead(src, &mouse, sizeof(mouse));
		}
```
`src/ints/mouse.cpp:1016-1022`

The struct contains two **host pointers**:

```c
	Bit16u*	screenMask;
	Bit16u* cursorMask;
```
`src/ints/mouse.cpp:102-103`

and the driver dereferences them when it draws the cursor:

```c
		Bit16u scMask = mouse.screenMask[addy+y-y1];
		Bit16u cuMask = mouse.cursorMask[addy+y-y1];
```
`src/ints/mouse.cpp:562-563`

So a guest program that calls AX=0017h can put arbitrary bytes into those two
pointers, and the next cursor draw dereferences them. This is a host-pointer
hazard — the same class of bug the save state already had to avoid.

It is upstream DOSBox r4305 code, not something this port introduced, and no
known game calls AX=0016h / 0017h, so the risk is theoretical. It is worth
noting because the correct pattern is already written elsewhere in the same
file.

**The fix.** After the read, re-derive the pointers instead of trusting the
guest's copy — exactly what `MOUSE_LoadState()` already does at
`src/ints/mouse.cpp:223-229`:

```c
    case 0x17: /* load driver state */
		{
			LOG(LOG_MOUSE,LOG_WARN)("Loading driver state...");
			PhysPt src = SegPhys(es)+reg_dx;
			MEM_BlockRead(src, &mouse, sizeof(mouse));
			// The struct carries two HOST pointers (screenMask, cursorMask).
			// Never take them from guest memory: re-derive them from the
			// cursor type, exactly as MOUSE_LoadState() does.
			if (mouse.cursorType == 2) {
				mouse.screenMask = userdefScreenMask;
				mouse.cursorMask = userdefCursorMask;
			} else {
				mouse.screenMask = defaultScreenMask;
				mouse.cursorMask = defaultCursorMask;
			}
		}
```

A tighter fix would read and write a guest-shaped struct that omits the
pointers entirely, but that changes the byte layout the guest sees, so it is a
behaviour change rather than a hardening. The re-derivation above preserves
behaviour.

---

## 5. Reference material

The full map of the interrupt layer — every vector, what it is for, and which
code answers it — was written for the public port, and it applies to this tree
too, because the BIOS and DOS layers here are upstream code that is
byte-identical:

- the repository → `docs/INTERRUPTS.md`
- the docs hub → <https://whereq.github.io/blog/WhereQ-DOSBox-Interrupts/>

The mouse driver's own reasoning is already written into the source, and it is
the best commentary on the subject:

- `src/ints/mouse.cpp:134-154` — why the save state keeps the configuration
  and drops the run-time state
- `src/gui/sdlmain.cpp:2642-2648` — why a click is a held button, and why
  that is an INT 33h AX=3 question
- `docs/TECHNICAL-REFERENCE.md` §4.7 — the touch-to-mouse conversion and the
  relative-mouse trap

---

## Summary of the actions

| # | What | Kind | Action |
|---|---|---|---|
| 1 | the "long-press" right button | documentation error, in the **other** project | none here — already fixed there |
| 2 | §1.3 change table omits `src/ints/mouse.cpp` | documentation defect | add one row; fix the "complete set" wording |
| 3 | the RMB key is dropped when `autolock=true` | **code defect**, conditional | force `autoenable=false` on Android |
| 4 | AX=0017h overwrites host pointers | upstream defect, theoretical | re-derive the pointers after the read |

Items 3 and 4 touch `src/`, so they change the emulator core and should be
verified on a device before a release: run a mouse-driven game, press the RMB
key, and confirm the game sees the right button; and load a save state in the
same game and confirm the cursor and the clicks still behave.
