# The Google Play Console listing — A-DOS

This is the sheet to fill the **Play Console** in with. Every field below is
the answer, written out, so nothing has to be worked out while the console is
open. It covers the release **1.0.0.0** (`versionCode` 1000000), package
`com.whereq.ados`.

`docs/PLAY-STORE.md` is the *guide* — why each requirement exists, what the
blockers were, how to enrol Play App Signing. This document is the *answers*.
Read this one while you are in the console.

**Nothing here needs a decision.** Every question has one answer, and the
answer is the one that matches what the app actually does. If you change the
app, change this file first — the listing, the privacy policy and the data
safety form have to agree with each other, and Play compares them.

---

## 1. At a glance

| Console field | Value |
|---|---|
| App name | `A-DOS` |
| Default language | English (United States) |
| App or game | **App** |
| Category | **Tools** |
| Price | Free |
| Contains ads | **No** |
| Short description | *DOSBox for Android: on-screen keyboard, save states, no ads, no tracking.* |
| Privacy policy URL | <https://whereq.github.io/docs/privacy/a-dos/> |
| Source code URL (used in the listing and in the app) | <https://whereq.github.io/docs/legal/a-dos-source/> |
| Contact email | `googol.zhang@gmail.com` |
| Data safety | **No data collected, no data shared** |
| Target audience | 13+ / general audience — not a children's app |
| Foreground service | **none** — the app declares no service at all, so there is nothing to declare |
| Version | 1.0.0.0 (`versionCode` 1000000) |
| Upload | the signed `.aab` — see [§8](#8-the-upload) |

---

## 2. Store listing

**Grow → Store presence → Main store listing**

### App name

```
A-DOS
```

Five characters, well inside the 30-character limit. Do not add a trademark
symbol or a subtitle here.

### Short description

Maximum 80 characters. This one is 73.

```
DOSBox for Android: on-screen keyboard, save states, no ads, no tracking.
```

### Full description

Maximum 4000 characters. This one is 2 501. Plain text — the console does not
render markdown, so the headings are written in capitals and separated by
blank lines.

```
A-DOS is a native Android port of DOSBox. The emulator core runs as a real
native library inside the app - not in a browser, not as a remote client - and
it runs DOS programs and DOS games on your phone, with the on-screen keyboard
and the touch mouse built in.

WHAT IT DOES

- Runs DOS programs and games. Install a .zip bundle, press Play, and the
  emulator reboots into it with a clean, freshly mounted C: drive.
- An on-screen keyboard in three layouts, one hand on each side of the screen,
  with an RMB key and a second-finger right click for the mouse.
- Touch is the mouse: move your finger to move the DOS cursor, tap to click,
  and use the arrow pad for the direction keys.
- A game mode: the on-screen keyboard turns into a gamepad - an 8-way D-pad,
  a trackball and a face button - in three profiles, with every button
  remappable per game. Open it with a Konami code on the keyboard.
- Save states: freeze the whole machine - the CPU, the DOS memory, the video
  memory, the open DOS file handles, the hardware timers and the sound chips -
  and resume it later, even after the app was killed.
- A durable saves folder. Pick a folder on your phone once, and every save
  state is mirrored into it, so your saves survive a reinstall, a new phone or
  an uninstall.
- A bundle launcher that installs a .zip, lists your games and starts them.
- Save states you can come back to: freeze the machine, leave the app, and
  pick the slot up again when you return.

WHAT IT DOES NOT CONTAIN

A-DOS contains no games, no ROMs and no DOS software. You bring the programs
you want to run, from your own files. The app downloads nothing and has no
network access at all: it does not even request the INTERNET permission, so it
cannot send anything anywhere.

The small example game that comes with the source code (STARFALL, written for
this project) is not part of the app - it is an example, published with the
source, for you to install yourself if you want to see how the launcher works.

FREE AND OPEN SOURCE

A-DOS is free software, licensed under the GNU General Public License,
version 2. The licence and the attribution notices travel with the app: open
the game launcher and tap "Licences" in its footer to read them. The complete
corresponding source code of every build is published, so anyone can read it,
change it and redistribute it:

https://whereq.github.io/docs/legal/a-dos-source/

PRIVACY

A-DOS collects nothing. No analytics, no ads, no crash reporting, no account.
Everything it writes stays on your device, and the only place it writes outside
its own storage is the saves folder you choose yourself. The full policy:

https://whereq.github.io/docs/privacy/a-dos/
```

> **Why the listing says what it says.** Two sentences carry the whole review:
> *"contains no games, no ROMs and no DOS software"* (the intellectual-property
> policy) and *"runs DOS programs ... inside an emulator"* (the policy that
> forbids downloading executable code — code that runs inside an emulator or
> interpreter is the documented exemption). A reviewer will look for both. Keep
> them if you edit the description.

### App icon

`resources/play/icon-512.png` — 512×512 PNG, 32-bit, no alpha, 120 KB.

Regenerate with:

```sh
./android/make-play-assets.py
```

### Feature graphic

`resources/play/feature-1024x500.png` — exactly 1024×500 PNG, 24-bit, **no
alpha**, 88 KB. The mark and the wordmark on the brand background.

### Phone screenshots

Four of them, all 1920×1080 (16:9), all 24-bit PNG with no alpha. Play accepts
between 2 and 8; the order below is the order they appear in the listing.

| # | File | What it shows |
|---|---|---|
| 1 | `resources/play/screenshot-01-home.png` | the DOS prompt after the boot, with the on-screen keyboard |
| 2 | `resources/play/screenshot-02-launcher.png` | the bundle launcher — *Install a bundle (.zip)*, the games list, the footer with the version and the links |
| 3 | `resources/play/screenshot-03-licences.png` | the licence screen: the GPLv2 summary and the link to the complete source |
| 4 | `resources/play/screenshot-04-starfall.png` | a game running — the STARFALL title screen |

> The screenshots are 16:9 on purpose. A phone capture is usually 20:9, and
> Play only accepts an aspect ratio between 16:9 and 9:16 — a 2400×1080
> capture is more than twice as wide as it is tall and the upload is refused.
> `android/make-play-assets.py` scales the capture to 1920×864 and centres it
> on a 1920×1080 canvas in the brand colour.

### Category and tags

**Tools** — that is the category the DOS emulators on Play sit in, and it is
what the app is: an emulator, not a game. (The listing itself says so: the app
ships no games.)

The tag list in the console depends on the category, so pick what fits from
the list it offers; nothing depends on the choice.

### Contact details

| Field | Value |
|---|---|
| Email address | `googol.zhang@gmail.com` |
| Phone | *(optional — leave empty unless you want to publish it)* |
| External marketing site | <https://whereq.github.io/docs/legal/a-dos-source/> |

The email must be the same address the privacy policy gives as its contact
point, because Play compares the two. `docs/PRIVACY.md` carries it.

---

## 3. App content — privacy policy

**Policy → App content → Privacy policy**

```
https://whereq.github.io/docs/privacy/a-dos/
```

Copy it exactly, with the trailing slash. The URL must answer HTTP 200 without
a login, from anywhere in the world, and must be a standard web page — Play
rejects a PDF or a downloadable file.

Check it before you submit:

```sh
url="https://whereq.github.io/docs/privacy/a-dos/"
curl -sL -o /dev/null -w '%{http_code} %{url_effective}\n' "$url"
curl -sL "$url" | grep -c "Privacy Policy"
```

The first line must print `200` and the URL you expect; the second must print a
number above zero. The policy page must name **A-DOS** and the developer
entity, and it does.

> Do **not** use a `whereq.com` URL here. That domain hosts a different
> product, and the path answers with an unrelated page — the reviewer would
> see the wrong thing.

---

## 4. App content — the data safety form

**Policy → App content → Data safety**

| Question | Answer |
|---|---|
| Does your app collect or share any of the required user data types? | **No** |
| Is all of the user data collected by your app encrypted in transit? | *(not asked — nothing is collected)* |
| Do you provide a way for users to request that their data be deleted? | *(not asked — nothing is collected)* |
| Does your app collect or share sensitive data (location, financial, health, messages, contacts, files)? | **No** |
| Is your data collection or sharing optional? | **No collection at all** |

Leave every data-type list empty and the "data shared with third parties"
toggle off. The form's own summary should read *no data collected, no data
shared*.

**Why this is true, and how to answer a reviewer who doubts it:**

* The app does not request the `INTERNET` permission. It cannot transmit
  anything even if it wanted to — there is no network code in the build.
* There is no analytics SDK, no crash reporter, no advertising SDK and no
  third-party service. The only runtime dependencies are the Kotlin standard
  library and AndroidX support libraries, and neither collects anything.
* The app writes to its own private storage (the installed bundles, the local
  save slots, the emulator configuration) and to **one** folder outside it: the
  durable saves folder **the user picks** through the system folder picker.
  That is the user's own file, chosen by the user, and the app only writes
  save files into it.
* There is no account, so there is no account to delete.

This matches `docs/PRIVACY.md`, which is published verbatim at the URL in
[§3](#3-app-content--privacy-policy). If one of them changes, change both.

---

## 5. App content — the other declarations

| Declaration | Answer |
|---|---|
| **Ads** | *Does your app contain ads?* → **No** |
| **App access** | *All features are available without special access* — no login, no account, no code. See the note below. |
| **Content ratings** | The IARC questionnaire, answered for the app's own content — see below. |
| **Target audience and content** | *Target age group* → **13 and above**; *Not primarily directed at children* → **No**. Families policy: not applicable. |
| **Government apps** | No |
| **Financial features** | This app does not provide any of the listed financial features |
| **News** | No |
| **COVID-19 contact tracing** | No |
| **Health apps** | No |
| **Privacy policy** | see [§3](#3-app-content--privacy-policy) |

### App access — the notes for the reviewer

> All features of the app are available without any special access: there is
> no account, no login and no code. The app boots straight into a DOS prompt.
>
> To see the bundle launcher working with a game in it, install the example
> bundle:
>
> 1. Download `a-dos-demo-bundle.zip` from
>    <https://whereq.github.io/downloads/a-dos-demo-bundle.zip>
> 2. Open A-DOS, tap the **File** key on the on-screen keyboard (top left) to
>    open the launcher, then tap **Install a bundle (.zip)**.
> 3. Pick the downloaded file. It appears in the list; tap **Play** and the
>    emulator reboots into STARFALL.
>
> The bundle is the original STARFALL demo written for this project; it is
> published with the source code, not part of the app.

### Content rating — how to answer the questionnaire

The questionnaire asks about the content **the app distributes**. A-DOS
distributes no games and no video, so the answers are *no* for violence,
sexual content, profanity, controlled substances, gambling and user-generated
content.

If the questionnaire offers a question about **user-supplied or downloaded
content**, the honest answer is that the app executes programs the user
supplies from their own device, inside the emulator, and that it does not
distribute, host, recommend or link to any content. The one example bundle
linked above is original work written for this project.

---

## 6. Foreground services: none

**Policy → App content → Foreground service declarations** (Android 14+)

**Leave this empty.** The app declares no service at all.

The earlier build ran a foreground service typed `specialUse` to hold the
emulator process while the player was in another app. It was removed: a
`specialUse` declaration has to be justified to Google Play, and the honest
answer — "this is a DOS emulator, there is no standard type for it" — is
exactly the kind of answer that draws a review question. So the app now
runs no service, asks for no `FOREGROUND_SERVICE`, no
`FOREGROUND_SERVICE_SPECIAL_USE` and no `POST_NOTIFICATIONS`, and shows no
ongoing notification.

What the player gets instead is the save state: A-DOS can freeze the whole
machine — the CPU, the DOS memory, the video memory, the open file handles,
the hardware timers and the sound chips — into a slot and resume it later,
even after the app was killed. The save states are mirrored into the durable
saves folder, so they survive a reinstall as well.

The app's own manifest is the check: `android/app/src/main/AndroidManifest.xml`
has no `<service>` element, and the built APK declares only `VIBRATE` and
the AndroidX-internal receiver permission.

---

## 7. The listing's other text fields

### Release notes (500 characters)

For the **1.0.0.0** production release:

```
A-DOS is the new name of the project - DOS across Android and Apple. This is
the first release of the A-DOS series: a new name, a new mark and a new
package (com.whereq.ados). New in this build: Game Mode - the on-screen
keyboard turns into a gamepad, with an 8-way D-pad, a trackball and three
profiles. The licence travels with the app, and the complete source code is
published.
```

### What's new — the long version

Same content, for the GitHub release notes and for the store's *What's new*
field once there is a second release. `docs/releases/1.0.0.0.md` is the
authoritative text.

### Promotional text (optional, 500 characters)

```
A native DOSBox for Android: the emulator core runs inside the app, with an
on-screen keyboard, touch mouse, save states and a bundle launcher. No ads, no
analytics, no accounts - and free software under the GPL.
```

---

## 8. The upload

### The two bundles, and which track each one goes to

A Play `versionCode` is unique **per app across every track**, not per track.
So the closed test and the production release cannot share one number, and
two bundles are built:

| Track | Artifact | `versionCode` | `versionName` | SHA-256 |
|---|---|---|---|---|
| Closed test | `a-dos-1.0.0.0.aab` | `1000000` | `1.0.0.0` | `598ae41ad7cdb28a3499ebeb37440062bfdf7fcb6a4afce81c48da75406ae2d4` |
| Production | `a-dos-1.0.0.0-vc1000001.aab` | `1000001` | `1.0.0.0` | `5b0e2fee0c405189e05a807b94b448d23d27dde8c35ed59122971ae392cab114` |

Both are published as release assets, each with a `.sha256` sidecar. They are
byte-for-byte the same app — the only difference is the version code — so the
production one is the *continuation* of the closed-test one, not a rebuild.

**Upload `1000000` to the closed track first** and `1000001` to production.
If the order is reversed, Play rejects the production upload, because a
version code can never go backwards for the same app.

The same pair exists as side-loaded APKs, for testing the upgrade path
locally before Play ever sees it: `a-dos-1.0.0.0.apk` (`1000000`) and
`a-dos-1.0.0.0-vc1000001.apk` (`1000001`).

### The upload itself

**Release → Production → Create new release**

| | |
|---|---|
| Artifact | `a-dos-1.0.0.0-vc1000001.aab` — the App Bundle, not the APK |
| `versionCode` | `1000001` |
| `versionName` | `1.0.0.0` |
| Target API | 36 |
| ABIs | `arm64-v8a`, `armeabi-v7a`, `x86_64` |
| Signing | the enrolled upload key — see below |

Play App Signing has to be **enrolled before the first upload**, and the app
signing key has to be the existing `whereq` release key, so that the Play
build and the GitHub APK share one certificate and the Play build installs
*over* the GitHub-installed app instead of replacing it:

```
b16b480d5a1ff6d35baff0b15fa3fc4b0ee815e500861fbff1b062c9bf7d3933
```

The full procedure — including how to reset a lost upload key — is in
`docs/PLAY-STORE.md` §6.3.

The console will run these checks itself, and A-DOS passes all of them:

* `targetSdk` ≥ 36 — set in `android/app/build.gradle`.
* 16 KB page sizes — every `PT_LOAD` segment of every native library is
  aligned to `0x4000`.
* `versionCode` higher than any previous version.
* The signature matches the enrolled upload key.
* All three ABIs are in the bundle.

---

## 9. Before you press submit

```sh
# 1. The policy page answers 200 and names the policy
url="https://whereq.github.io/docs/privacy/a-dos/"
curl -sL -o /dev/null -w '%{http_code} %{url_effective}\n' "$url"
curl -sL "$url" | grep -c "Privacy Policy"

# 2. The source page and the archive are public
curl -sL -o /dev/null -w '%{http_code} %{url_effective}\n' \
  "https://whereq.github.io/docs/legal/a-dos-source/"
curl -sL -o /dev/null -w '%{http_code} %{size_download}\n' \
  "https://whereq.github.io/downloads/a-dos-1.0.0.0-source.tar.gz"

# 3. The demo bundle the reviewer is told to download
curl -sL -o /dev/null -w '%{http_code} %{size_download}\n' \
  "https://whereq.github.io/downloads/a-dos-demo-bundle.zip"

# 4. The listing assets are the committed ones, and they are legal
./android/make-play-assets.py --check
```

`make-play-assets.py --check` re-renders the assets from the brand and the
captures and compares them with the committed files. It prints nothing and
exits 0 when they match.

---

## 10. The checklist

**Store listing**

- [ ] App name `A-DOS`, default language English (United States), type *App*
- [ ] Category *Tools*, free, no ads
- [ ] Short description and full description pasted from [§2](#2-store-listing)
- [ ] Icon `resources/play/icon-512.png` (512×512, no alpha)
- [ ] Feature graphic `resources/play/feature-1024x500.png` (1024×500, no alpha)
- [ ] Screenshots 1–4 uploaded, in that order
- [ ] Contact email `googol.zhang@gmail.com`

**App content**

- [ ] Privacy policy URL
- [ ] Ads: *No ads*
- [ ] Data safety: *no data collected, no data shared*
- [ ] App access: all features available without special access + the demo
      bundle note
- [ ] Content rating questionnaire finished
- [ ] Target audience: 13+, not directed at children
- [ ] Government / financial / news / health / COVID-19: all *no*
- [ ] Foreground service declarations: **empty** — the app declares no service

**Release**

- [ ] Play App Signing enrolled with the `whereq` key
- [ ] The closed track got `a-dos-1.0.0.0.aab` (`versionCode` `1000000`)
- [ ] The `.aab` uploaded to production — `a-dos-1.0.0.0-vc1000001.aab`
      (`versionCode` `1000001`), see [§8](#8-the-upload)
- [ ] Release notes pasted from [§7](#7-the-listings-other-text-fields)
- [ ] The Play-installed build verified on a device
- [ ] The Play build confirmed to install **over** the GitHub-installed app

---

## 11. Where the source code is published

This is the answer to the question that comes up with the GPL, and it is the
same answer for the Play reviewer, for a user and for anyone else who asks.

**The complete corresponding source of every A-DOS release is published on the
public WhereQ site, as a source archive:**

```
https://whereq.github.io/downloads/a-dos-1.0.0.0-source.tar.gz
```

| | |
|---|---|
| Archive | `a-dos-1.0.0.0-source.tar.gz` (32 205 547 bytes) |
| SHA-256 | `89efed3e52c2f3547f478201f0326cf755f57a514001896e77b56d85b536986c` |
| Source commit | `652ddb2` — the tree the shipped build was made from, and the tree the `v1.0.0.0` tag points at |
| Page that documents it | <https://whereq.github.io/docs/legal/a-dos-source/> |

The archive is the tree of the release commit plus a `SOURCE-RELEASE.md` that
names the version, the commit and the build. It holds the DOSBox core with its
per-file copyright and licence headers intact, the Android application, the
NDK/CMake build of the native library, the desktop Linux baseline, the
benchmark, the dev toolchain and the build scripts.

Verify it before you build it:

```sh
curl -LO https://whereq.github.io/downloads/a-dos-1.0.0.0-source.tar.gz
sha256sum a-dos-1.0.0.0-source.tar.gz
# 89efed3e52c2f3547f478201f0326cf755f57a514001896e77b56d85b536986c
```

**SDL2 is not in the archive.** It is zlib-licensed, so its notice has to
travel with the binary but not its source. `third_party/fetch-sdl2.sh` pins the
exact release the build uses — SDL2 **2.30.0** — and the `NOTICE` file carries
its notice. The app ships the notice too: `COPYING` and `NOTICE` are bundled
as assets and shown by the licence screen.

The development repository itself stays private. GPLv2 does not require the
development repository to be public — it requires that **everyone who
receives the program receives its source as well**, which the published
archive does, for every build.

---

## See also

* `docs/PLAY-STORE.md` — the guide: the blockers, Play App Signing, the
  timeline, the policy notes
* `docs/PRIVACY.md` — the authoritative privacy policy (published verbatim)
* `docs/releases/1.0.0.0.md` — the release notes
* `android/make-play-assets.py` — the asset generator
* `NOTICE`, `COPYING` — the attribution and the licence
